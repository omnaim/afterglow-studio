# AFTERGLOW Studio — local ComfyUI production tools

Two all-in-one workflows share one install. Upload a PDF or picture, choose a project name, and press Run. The default delivery is a **90-second, 1080×1920, 24 fps MP4 with Arabic speech and no music generator**.

This is an implemented, research-informed development build. CPU orchestration/render tests passed. The large models, complete installer and live ComfyUI interface still require acceptance testing on your GPU. No generated cinematic sample or Arabic lip-sync result has been validated for this release.

## The two versions

| Workflow | Use | Production behavior |
|---|---|---|
| `workflows/01_Series_and_Movie.json` | Narrative shorts, episodes and film sequences | Persistent cast portraits, synthetic voice references, wardrobe/style bible, chapter outline, shot continuity, Arabic dialogue/voiceover, H3 video, Foley and editorial exports. |
| `workflows/02_Motion_and_Product.json` | Product films, motion graphics, animated illustrations and brand videos | Original product/logo layers, Arabic typography, deterministic graphic animation, optional H3 product/scene animation, background generation, sound effects and alpha overlays. |

The JSONs use the **included custom nodes**. Importing a JSON without installing the package will show missing nodes. The small front graph runs a full local production engine; the model stages and saved native API graphs are available on disk for inspection.

## One-time setup on the rented GPU

Linux, an NVIDIA CUDA environment, Python 3.11/3.12, FFmpeg/FFprobe, Git and Arabic-capable fonts are required. Keep models and outputs on persistent storage. The seven native ComfyUI weights alone total **156.04 GB decimal**, before the planner, speech, segmentation, Foley models, Python environments and rendered takes.

On a Debian/Ubuntu image with root access, these system packages supply the basic utilities:

```bash
apt-get update
apt-get install -y git ffmpeg python3-venv fonts-noto-core fonts-dejavu-core
```

Extract the ZIP, enter its `afterglow-studio` directory, then choose ONE setup route.

**A. New isolated ComfyUI installation — preferred for this version:**

```bash
python3 tools/setup_local.py \
  --install-comfy \
  --comfy-root /workspace/ComfyUI-Studio \
  --runtime-root /workspace/studio_runtime
```

The target must be new/empty. This installs the inspected ComfyUI commit `14c553159994b626738c392eb99d295ea3d683c1` and its own Python environment. If setup is interrupted after ComfyUI exists, repeat the command **without** `--install-comfy`; already verified model downloads resume.

**B. Existing up-to-date ComfyUI:**

```bash
python3 tools/setup_local.py \
  --comfy-root /workspace/ComfyUI \
  --comfy-python /workspace/ComfyUI/.venv/bin/python \
  --runtime-root /workspace/studio_runtime
```

The existing core must include `MiniMaxH3ReferenceToVideo`, `MiniMaxH3AddGuide` and `TextEncodeQwenImage21`. The installer checks this before downloading models. It preserves the existing host Torch installation; isolated workers use a selected matched Torch/TorchVision/TorchAudio trio. The default is Torch 2.10.0/CUDA 12.8. `--torch-version`, `--torch-index` and `--base-python` are available for a different driver image. Full dependency installation has not been exercised in this environment.

For an update of this custom-node pack, add `--replace-pack`; the existing pack is backed up. Existing AFTERGLOW v1 workflows can coexist with Studio.

Launch the new instance, or restart your existing instance through your GPU provider's normal protected ComfyUI access:

```bash
/workspace/ComfyUI-Studio/.venv/bin/python /workspace/ComfyUI-Studio/main.py \
  --listen 127.0.0.1 --port 8188 --max-upload-size 200
```

Use your existing proxy/tunnel configuration when accessing a rented machine remotely. The one-time installer downloads public model/code files. **Inference uses local model paths and offline flags; no hosted inference or paid API credentials are used.** Third-party extensions in an existing ComfyUI installation retain their own behavior.

Before a large job, run the supplied compatibility check with the installed vision environment:

```bash
/workspace/studio_runtime/envs/vision/bin/python tools/doctor.py \
  --config /workspace/ComfyUI-Studio/custom_nodes/ComfyUI-Afterglow-Studio/config.json
```

Add `--smoke-source /workspace/ComfyUI-Studio/input/studio_uploads/your_file.png --mode film` to run a real 15-second Preview through the complete model pipeline. This is optional inference work and will consume your rented GPU time.

## Upload → Run

1. Drag the appropriate workflow JSON into ComfyUI.
2. Click **Upload PDF / image**. Supported: unlocked PDF with 1–16 pages, PNG, JPG, JPEG, WebP; up to 200 MiB with the launch setting above. PDF intake extracts original embedded images and page text before considering page screenshots.
3. Set a short project name, such as `afterglow_series` or `perfume_launch`. Defaults already select Production quality, 90 seconds and vertical delivery.
4. Press **Run**. Progress appears in the director node; the completed MP4 plays there.

Optional controls: duration 15–3600 seconds, vertical/landscape/square output, creative brief, episode number, seed and editorial delivery. Long pieces are planned in blocks of up to twelve shots, following one outline. A feature-length project can be produced in consecutive parts under the same project and conformed from the supplied timelines; this version does not automatically stitch multiple episode masters into a feature.

## Series and movie operation

Keep the **same project name** to reuse the exact stored cast images and synthetic voice reference files. Increase `episode` for the next installment. Its planner receives the previous completed Production episodes' outlines and ending states. The original bible remains fixed; a new project name creates a new cast/style.

A series episode contains a mix of 4–8-ish second shots with frame-exact scheduling. They are generated individually so bad takes can be replaced. Adjacent shot keyframes and fixed original portraits condition H3; previous generated video is not repeatedly recycled as the identity source.

Arabic speech is generated first, checked by local Whisper, and timed without cutting off words. The same waveform guides H3 for visible dialogue and enters the final mix. Visible dialogue is staged one speaker per shot; multi-person conversations use separate coverage/voiceover. This supports up to six recurring cast members, three visible characters per non-dialogue shot. It does not recover a real person's voice from a picture.

## Motion and product operation

`visual_mode` controls subject treatment:

- **Automatic:** uses Product artwork when the source contains a selected product; otherwise Scene animation.
- **Product artwork:** BiRefNet HR supplies a mask; the original RGB artwork stays intact. Product movement is a controlled flat layer: float, slide, reveal, push or detail emphasis. Decorative arcs may orbit it. It does not invent unseen product sides.
- **Product animation:** the original product also conditions Qwen/H3, which can animate it within the scene. Its labels/geometry receive visual review, but generative fidelity is not guaranteed. Use additional views or a real 3D asset for accurate unseen surfaces; this upload version is not a CAD/3D reconstruction tool.
- **Scene animation:** animates an uploaded illustration, photograph or scene while preserving its style. Text is composited separately.

`background=H3 animated background` enables H3 movement for the chosen visual mode. `Graphic motion` uses a generated still with a deterministic push and animated graphic layers; choose H3 when the subject itself needs to move.

Typography is shaped as Arabic with RAQM and rendered from exact text. It is never delegated to the video generator. Graphic copy comes from the source; prompts forbid invented product claims. Three palette colors and product/logo crops are stored in the project bible. Product extraction and text recognition can still need correction if the source is ambiguous or low resolution.

## Quality and delivery

**Production:** three keyframe candidates and three video candidates per shot; another three are attempted for shots that fail review. The reviewer compares original identities, texture, geometry, intent and sampled temporal consistency. A hard reject or score below 7.5 holds the master if retries do not resolve it. Motion-design composites receive a further review against original artwork and headline text. These scores are estimates, not certification.

**Preview:** one candidate, gates bypassed, output named `PREVIEW.mp4`. It does not advance the series story. Production output is `MASTER.mp4`.

Completed stages and candidate files survive a failed job. Repeating Run with the same file content and options resumes or returns the completed result. A new seed or revised brief starts a new render while preserving the project cast. For a quality hold, inspect `quality_hold.json`, candidate reports and contact sheets, then revise the brief/source or seed. Do not manually delete only part of a cached render; use a new seed to regenerate it coherently.

Outputs live in:

```text
ComfyUI/output/studio_projects/<project>/
  bible.json, anchors.json, casting.json, history.json
  voices/, brand_layers/
  episode_001/<render-id>/
    MASTER.mp4                 # H.264 CRF16, SDR Rec.709, AAC stereo 48 kHz
    MASTER.mov                 # ProRes 422 HQ when edit_pack is enabled
    Arabic_and_Foley.wav       # measured two-pass -16 LUFS target, -1.5 dBTP
    Arabic.srt                 # editable sidecar; not burned into film footage
    edit.edl, timeline.json     # 24 fps edit conform data
    plan.json, outline.json
    clips/, takes/, alpha_overlays/
    *_candidate_report.json, *_execution.json, *.log
```

Keyframes and exact speech waveforms live under matching ComfyUI `input/studio_projects/...` paths. Persistent cast assets are in `input/studio_cast/<project>`. Keep both input and output project folders together when migrating machines. Paths in this version's edit files are absolute; relink footage after migration.

With `edit_pack=true`, design shots also export transparent ProRes 4444 graphic overlays. AI footage is decoded to 8-bit RGB for these image pipelines; a 10-bit ProRes container does not create genuine camera RAW, HDR or extra source bit depth. The supplied alpha layers and JSON layout preserve downstream editability, but are not native After Effects or Blender projects.

No music model is installed or invoked. H3's synthesized audio is discarded. Final sound consists of checked Arabic speech plus Hunyuan Foley for films, or short procedural movement effects for design. Foley generation is prompted to exclude voices and music, with a speech-activity rejection check; it is not a perfect audio-content classifier.

## What has and has not been verified

See `VALIDATION_REPORT.json` for the actual test record and `RESEARCH_AND_MODEL_CHOICES.md` for dated primary sources. Schema tests, synthetic orchestration, timing, RTL text and file output are engineering checks. They cannot establish cinematic realism, pronunciation, Saudi accent, identity stability or lip synchronization. Those remaining checks require the installed models on your GPU and review of actual generated footage.
