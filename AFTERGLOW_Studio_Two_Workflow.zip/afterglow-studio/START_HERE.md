Package review update: Torch version constraints, CPU-build probe correction, local-builder disk check, your Docker Hub destination, and an optional manual GitHub validation workflow have been added. Upload this updated ZIP instead of an earlier copy.

# RunPod template build kit added

For automatic setup on fresh pods without a persistent volume, see `runpod/README.md`. It contains the Docker build and private-template publishing steps. The image is not built/published yet. The notebook option below remains available.

# AFTERGLOW — Jupyter edition

## Use it
1. Upload `AFTERGLOW_Studio_Two_Workflows.zip` to `/workspace` in Jupyter.
2. Extract the ZIP. If Jupyter has no Extract command, open its Terminal and run:
   `python -m zipfile -e AFTERGLOW_Studio_Two_Workflows.zip .`
3. Open `afterglow-studio/OPEN_ME.ipynb`. Run the **Software setup** cell.
4. Restart your existing ComfyUI service. If you do not have one running, use the notebook's optional start cell. Your RunPod template must expose port 8188.
5. Drag `workflows/01_Series_and_Movie.json` or `workflows/02_Motion_and_Product.json` into ComfyUI.
6. Click **Download / resume models** on the production node. Choose the profile and start. Wait for READY.
7. Upload your picture or PDF through the source node. Run the workflow.

The two JSON files are inside the ZIP; there is no separate JSON download required. The advanced `_API.json` files are for API users, not normal drag-and-drop import.

## What changed
- Model downloads now run from a panel inside ComfyUI. These are AFTERGLOW buttons, not an assumed ComfyUI Manager missing-model popup.
- The notebook installs software only, with no automatic model downloads.
- Film, design, graphics-only, and full model profiles. All retain Arabic speech models. Graphics-only requires the `Graphic motion` background setting.
- Shared persistent pip cache, reusable working Torch triplets, and a software checkpoint checked against installed package lists.
- Native weight downloads resume partial files, verify SHA-256, and reuse verification receipts while size and modification time remain unchanged. Delete a receipt to force a full recheck.
- The panel can stop/resume downloads; closing it does not stop the server's download process.
- Missing profile models produce an actionable error before rendering starts.

## Avoid another expensive reinstall
Keep the ComfyUI directory AND `/workspace/afterglow-data` on an attached RunPod NETWORK VOLUME. `/workspace` by itself does not guarantee persistence. Ordinary pod storage can disappear on termination. Existing completed files are reused in their configured locations; files elsewhere are not automatically migrated or duplicated.

Normal starts require only launching ComfyUI. Do not run setup on every boot. Re-running the notebook checks the completed software checkpoint; interruptions before that checkpoint use pip's shared cache and already-installed packages. Worker environments remain separate because their dependencies differ. This release does not contain a prebuilt Docker image and does not eliminate the first software installation.

## Requirements and limits
Linux; Python 3.11/3.12; working NVIDIA driver; git; ffmpeg/ffprobe; sufficient disk and GPU memory. Existing ComfyUI must contain the pinned model node interfaces used by Studio. Setup stops early if incompatible instead of modifying it automatically. For a separate managed installation, change COMFY_ROOT in the notebook to `/workspace/ComfyUI-Afterglow` and expose that server's port.

A clean machine cannot render immediately after unzipping: packages and model weights are not bundled. Full native weights alone total about 156 GB, plus planning, Arabic speech and other supporting models. Graphics-only is smaller but still needs substantial downloads. No music-generation model is installed. All inference runs locally on your GPU server.

If the notebook kernel is not the Python interpreter used by your existing ComfyUI and no `.venv`/`venv` is present, use `tools/jupyter_setup.py --python /absolute/path/to/comfy/python --comfy-root /workspace/ComfyUI`.

Setup logs appear in the notebook; model logs appear in the panel and `custom_nodes/ComfyUI-Afterglow-Studio/model_download.log`. A failed model download is resumable. Completed stages are retained. Restarting ComfyUI stops its UI connection; do not restart during a download. Secure access through your RunPod proxy as you would for ComfyUI itself.

## Validation
Python compilation, JavaScript syntax, native-download resume/checksum/receipt tests, and all profile-selection/configuration tests passed locally. Real GPU dependency installation, actual model inference, and the live ComfyUI browser panel have not been tested on your rented pod. No instant-start or production-quality guarantee is claimed.

See `ADVANCED_SETUP.md` for the earlier production architecture. Its full-install commands download models from the terminal; use this notebook flow for in-ComfyUI downloads.
