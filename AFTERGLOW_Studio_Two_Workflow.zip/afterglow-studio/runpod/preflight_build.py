"""Check a LOCAL Docker builder's available disk before a costly build."""
import argparse,os,shutil,subprocess
from pathlib import Path
MIN_GIB=150

def require_space(path,minimum_gib=MIN_GIB):
    free=shutil.disk_usage(path).free/1024**3
    if free<minimum_gib:
        raise RuntimeError(f'Only {free:.1f} GiB free on Docker storage; this unmeasured large build requires a planning allowance of {minimum_gib} GiB. Do not run it on a standard GitHub runner. Use a larger CPU builder. This allowance is not a measured image-size guarantee.')
    return free

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--minimum-gib',type=int,default=MIN_GIB);a=p.parse_args()
    if not shutil.which('docker'):raise SystemExit('Docker builder unavailable. No build started.')
    endpoint=os.environ.get('DOCKER_HOST') or subprocess.check_output(['docker','context','inspect','--format','{{.Endpoints.docker.Host}}'],text=True).strip()
    if not endpoint.startswith('unix://'):raise SystemExit('This check supports local Docker daemons only. Remote builder disk capacity must be checked on that builder before running the documented docker build command.')
    root=Path(subprocess.check_output(['docker','info','--format','{{.DockerRootDir}}'],text=True).strip())
    if not root.exists():raise SystemExit('Docker storage is not visible on this host; verify capacity inside its VM first.')
    print(f'Build preflight passed: {require_space(root,a.minimum_gib):.1f} GiB available. No model weights are downloaded during image build.')

if __name__=='__main__':main()
