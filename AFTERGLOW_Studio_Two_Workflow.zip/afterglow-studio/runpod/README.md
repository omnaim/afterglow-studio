# AFTERGLOW RunPod template build kit

Status: source prepared and CPU checks passed. Container build, registry publication, and GPU acceptance have NOT been performed. This ZIP is not an already-published RunPod template.

## One-time publishing
Build on a Linux x86-64 machine with Docker/BuildKit and sufficient disk space (allow at least 150 GB as an initial build estimate; actual image size must be measured). A GPU is not required for the image build. Do not rent an expensive GPU just to build it. Separate worker environments make this a large software image even without weights.

From the extracted `afterglow-studio` directory:

```bash
docker login -u tylersabrin
bash runpod/build.sh tylersabrin/afterglow-studio:1.0.0
docker push tylersabrin/afterglow-studio:1.0.0
```

Use your Docker Hub access token at the login prompt, not in source files. Create/select your Docker Hub repository first. If private, add its pull credentials under RunPod Container Registry Settings and select them on the template before deploying.

Review the template configuration (no account access or mutation):

```bash
python runpod/create_template.py --image tylersabrin/afterglow-studio:1.0.0
```

After the image has successfully built and been pushed, set RUNPOD_API_KEY securely in your terminal environment, then create the private template:

```bash
python runpod/create_template.py --image tylersabrin/afterglow-studio:1.0.0 --apply
```

This creates only a template. It never rents or launches a Pod. Alternatively, copy the dry-run settings into RunPod's New Template form; use a strong Jupyter password instead of the dry-run placeholder. Keep Docker command and entrypoint overrides empty so the image startup remains intact.

## Everyday use
1. Choose your private AFTERGLOW template and a compatible GPU.
2. Leave network volume unattached. Initial container disk setting: 500 GB, an estimate rather than a measured guarantee for all models and production outputs. Review storage charges before launching.
3. Set AFTERGLOW_PROFILE to `film`, `design`, `graphics`, or `full` (default).
4. Launch. Open ComfyUI on port 8188 once it starts.
5. The two workflows are preloaded in ComfyUI's workflow directory and copied to `/workspace/afterglow/workflows`.
6. Open **Download / resume models** to monitor automatic downloads. Wait for the selected profile to become ready, then upload your reference and render.

Jupyter uses port 8888. Your generated Jupyter password is stored in the private template environment settings. The boot supervisor logs to `/workspace/afterglow/startup.log`. Model transfer logs are shown inside ComfyUI.

Graphics profile does not include H3 weights: select Graphic motion in the design node. All profiles include Arabic speech. `AFTERGLOW_AUTODOWNLOAD=0` disables automatic transfer and leaves downloads under manual UI control.

## What happens automatically
- Official RunPod startup retains SSH and Jupyter.
- CPU-built software environments live under `/opt`; startup does not run pip or the installer.
- GPU kernel checks run in each worker environment before downloading large weights.
- ComfyUI launches, then the supervisor starts model downloads through the same API used by the UI. Stop/resume and progress remain available.
- Native weights are resumed and SHA-256 verified. HF snapshots use pinned revisions. Changed files/revisions invalidate readiness as documented by the model manager.
- A failed download stops without an infinite retry loop. ComfyUI remains open so you can inspect the error and resume.

No persistent storage is required. A NEW pod must transfer missing weights again, and runtime input/output/project data will not survive ephemeral storage destruction. Download finished videos and any character/voice continuity files before terminating. The full native weights alone are approximately 156 GB; planning, speech and supporting models add more. Template automation saves manual work and dependency installation; it does not eliminate image-pull or model-download time.

## Acceptance before relying on this template
1. Build completes, including all worker import checks.
2. Push succeeds and the registry image tag exists.
3. On a test GPU, confirm all boot GPU checks pass and /object_info exposes StudioFilm and StudioDesign.
4. Confirm the automatic download panel reaches ready for the selected profile.
5. Render one short Arabic film clip and one motion-design clip; inspect video/audio and export.
6. Terminate only after saving outputs. Create a fresh pod with the same template and verify automatic cold-start downloads.

Local checks completed: Python compile, shell syntax, boot path relocation, workflow installation, readiness reuse/invalidation, unexpected-weight protection; earlier model-download resume/integrity/profile/process tests. No real Docker or GPU build was available in the authoring environment.

## References
- https://docs.runpod.io/pods/templates/create-custom-template
- https://docs.runpod.io/api-reference/templates/POST/templates

## Pre-upload review update
The default destination is `tylersabrin/afterglow-studio:1.0.0`. CPU image builds no longer require GPU allocation probes. Managed environments constrain Torch/vision/audio versions during subsequent pip installs; incompatible package requirements now fail rather than silently changing that triplet. This is not a complete transitive dependency lock or proof of model compatibility.

`build.sh` checks a local Docker daemon's visible storage first, using a conservative, unmeasured 150 GiB free-space allowance. Remote Docker builders need their capacity checked on the remote host; the local script stops if it cannot inspect that storage. The standard GitHub runner is unsuitable for this image build.

`runpod/github-validate.yml` is an optional **manual validation-only** GitHub workflow. To enable it later, copy its contents into `.github/workflows/validate-afterglow.yml` using GitHub's Create new file editor. Uploading the ZIP by itself does not install a GitHub workflow. The check extracts the archive on GitHub, checks integrity and runs small dependency-free tests. It neither builds an image nor downloads weights nor accesses Docker Hub/RunPod. It uses GitHub Actions minutes according to your plan. No workflow runs on push; only an explicit Run workflow starts validation.

Updated source tests are provided, but the container still needs its first real Docker build and GPU acceptance test. Do not treat a successful source check as a working production image.
