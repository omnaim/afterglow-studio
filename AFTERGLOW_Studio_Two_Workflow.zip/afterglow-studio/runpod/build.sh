#!/usr/bin/env bash
set -euo pipefail
if [[ $# -eq 0 ]]; then set -- tylersabrin/afterglow-studio:1.0.0; fi
if [[ $# -ne 1 || "$1" != *:* || "$1" == *:latest ]]; then
  echo 'Usage: bash runpod/build.sh YOUR_DOCKERHUB_USERNAME/afterglow-studio:1.0.0'; exit 2
fi
cd "$(dirname "$0")/.."
python3 runpod/preflight_build.py
docker build --platform linux/amd64 -f runpod/Dockerfile -t "$1" .
echo "Built $1. Review the build logs, then publish with: docker push $1"
