"""No dependency installation at boot. Launch ComfyUI, then its model download API."""
import fcntl,json,os,shutil,signal,subprocess,time,urllib.request
from pathlib import Path

COMFY=Path('/opt/ComfyUI')
SOURCE=Path('/opt/afterglow-source')
CONFIG=COMFY/'custom_nodes/ComfyUI-Afterglow-Studio/config.json'

def api(method='GET',body=None):
    req=urllib.request.Request('http://127.0.0.1:8188/afterglow-studio/models',method=method,data=json.dumps(body).encode() if body else None,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)

def prepare(data,template):
    for name in ('models','hub','input/studio_uploads','output','workflows'):(data/name).mkdir(parents=True,exist_ok=True)
    cfg=json.loads(template.read_text())
    cfg.update(input_dir=str(data/'input'),output_dir=str(data/'output'),hub_cache=str(data/'hub'),models={},ready_profiles=[])
    # Preserve existing downloads/config only for the same pinned model revisions.
    if CONFIG.exists():
        old=json.loads(CONFIG.read_text())
        if old.get('hub_cache')==cfg['hub_cache'] and old.get('model_revisions')==cfg['model_revisions']:
            cfg['models']=old.get('models',{});cfg['ready_profiles']=old.get('ready_profiles',[])
    target=COMFY/'models'
    if target.is_symlink():
        if target.resolve()!=(data/'models').resolve():raise RuntimeError('Existing model symlink points elsewhere.')
    elif target.exists():
        # Stock ComfyUI placeholder files are retained. Never move installed weights silently.
        for file in target.rglob('*'):
            if file.is_file() and file.stat().st_size>1024*1024:raise RuntimeError('Unexpected baked weights in ComfyUI/models.')
        shutil.copytree(target,data/'models',dirs_exist_ok=True);shutil.rmtree(target);target.symlink_to(data/'models',target_is_directory=True)
    else:target.symlink_to(data/'models',target_is_directory=True)
    CONFIG.write_text(json.dumps(cfg,indent=2))
    workflowdir=COMFY/'user/default/workflows';workflowdir.mkdir(parents=True,exist_ok=True)
    for name in ('01_Series_and_Movie.json','02_Motion_and_Product.json'):
        shutil.copy2(SOURCE/'workflows'/name,data/'workflows'/name)
        shutil.copy2(SOURCE/'workflows'/name,workflowdir/name)
    return cfg

def main():
    profile=os.environ.get('AFTERGLOW_PROFILE','full')
    if profile not in ('film','design','graphics','full'):raise ValueError('AFTERGLOW_PROFILE must be film, design, graphics or full')
    data=Path(os.environ.get('AFTERGLOW_DATA','/workspace/afterglow')).resolve();data.mkdir(parents=True,exist_ok=True)
    with (data/'boot.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        cfg=prepare(data,Path('/opt/afterglow-runtime/image-config.json'))
        print('Checking GPU kernels before model downloads.',flush=True)
        for role,exe in cfg['python'].items():
            subprocess.run([exe,'-c','import torch; assert torch.cuda.is_available(); x=torch.ones((32,32),device="cuda",dtype=torch.bfloat16); print(torch.__version__,torch.cuda.get_device_name(0),(x@x).sum().item())'],check=True)
            print('GPU check passed: '+role,flush=True)
        child=subprocess.Popen([cfg['python']['comfy'],str(COMFY/'main.py'),'--listen','0.0.0.0','--port','8188','--input-directory',cfg['input_dir'],'--output-directory',cfg['output_dir']],cwd=COMFY,start_new_session=True)
        def stop(*args):
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
            raise SystemExit(0)
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
        try:
            for _ in range(150):
                if child.poll() is not None:raise RuntimeError('ComfyUI exited; inspect startup.log')
                try:api();break
                except (OSError,ValueError):time.sleep(2)
            else:raise RuntimeError('ComfyUI failed to start within 5 minutes')
            if os.environ.get('AFTERGLOW_AUTODOWNLOAD','1')=='1':
                api('POST',{'profile':profile})
                print('Automatic downloads started for '+profile+'. Monitor the workflow download panel.',flush=True)
                while child.poll() is None:
                    status=api()
                    if not status['running']:
                        if status.get('exit_code')==0 and profile in status['ready_profiles']:print('AFTERGLOW READY: models downloaded. GPU inference quality is not yet verified.',flush=True)
                        else:print('DOWNLOAD STOPPED. Open Download / resume models to inspect the error and retry. No automatic retry loop.',flush=True)
                        break
                    time.sleep(5)
            print('ComfyUI available on port 8188. No pip installation ran at startup.',flush=True)
            raise SystemExit(child.wait())
        finally:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=20)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()

if __name__=='__main__':main()
