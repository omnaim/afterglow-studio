#!/usr/bin/env bash
set -euo pipefail
mkdir -p "${AFTERGLOW_DATA:-/workspace/afterglow}"
python /opt/afterglow-source/runpod/boot.py >> "${AFTERGLOW_DATA:-/workspace/afterglow}/startup.log" 2>&1 &
