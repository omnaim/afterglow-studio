import importlib.util,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
root=Path(__file__).resolve().parents[1]
setup=load('setup_test',root/'tools/setup_local.py');preflight=load('space_test',root/'runpod/preflight_build.py')

class Guards(unittest.TestCase):
    def test_cpu_build_reuses_torch_without_gpu_probe(self):
        with tempfile.TemporaryDirectory() as temp:
            python=Path(temp)/'env/bin/python';python.parent.mkdir(parents=True)
            with patch.object(setup.subprocess,'run',return_value=types.SimpleNamespace(returncode=0)) as run:
                setup.torch_install(python,'https://example.invalid','2.10.0',True)
                self.assertEqual(run.call_count,1)
                self.assertNotIn('cuda.is_available',run.call_args.args[0][2])
            constraint=python.parent.parent/'afterglow-torch-constraints.txt'
            self.assertIn('torchvision==0.25.0',constraint.read_text())
            with patch.object(setup.subprocess,'run') as run:
                setup.run([python,'-m','pip','install','example-package'])
                self.assertIn('--constraint',run.call_args.args[0])
                self.assertIn(str(constraint),run.call_args.args[0])
    def test_regular_setup_still_probes_gpu(self):
        with tempfile.TemporaryDirectory() as temp:
            python=Path(temp)/'env/bin/python';python.parent.mkdir(parents=True)
            with patch.object(setup.subprocess,'run',return_value=types.SimpleNamespace(returncode=0)) as run:
                setup.torch_install(python,'https://example.invalid','2.10.0')
                self.assertIn('cuda.is_available',run.call_args.args[0][2])
    def test_low_disk_fails_before_build(self):
        with patch.object(preflight.shutil,'disk_usage',return_value=types.SimpleNamespace(free=14*1024**3)):
            with self.assertRaisesRegex(RuntimeError,'Only 14.0'):preflight.require_space('.')
        with patch.object(preflight.shutil,'disk_usage',return_value=types.SimpleNamespace(free=200*1024**3)):
            self.assertEqual(preflight.require_space('.'),200)

if __name__=='__main__':unittest.main()
