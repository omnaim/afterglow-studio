import importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('boot',Path(__file__).with_name('boot.py'));boot=importlib.util.module_from_spec(spec);spec.loader.exec_module(boot)

class BootTests(unittest.TestCase):
    def test_prepare_model_paths_workflows_and_resume(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);comfy=root/'comfy';source=root/'source';data=root/'data';config=comfy/'node/config.json'
            config.parent.mkdir(parents=True);(comfy/'models/diffusion_models').mkdir(parents=True);(source/'workflows').mkdir(parents=True)
            (comfy/'models/diffusion_models/put_models_here').touch()
            for name in ('01_Series_and_Movie.json','02_Motion_and_Product.json'):(source/'workflows'/name).write_text('{}')
            template=root/'template.json';template.write_text(json.dumps({'model_revisions':[{'revision':'a'}],'python':{'comfy':'/opt/python'},'native_models':{}}))
            with patch.multiple(boot,COMFY=comfy,SOURCE=source,CONFIG=config):
                cfg=boot.prepare(data,template)
                self.assertTrue((comfy/'models').is_symlink());self.assertEqual(cfg['ready_profiles'],[])
                self.assertEqual(cfg['input_dir'],str(data/'input'))
                self.assertTrue((comfy/'user/default/workflows/01_Series_and_Movie.json').exists())
                cfg['ready_profiles']=['film'];cfg['models']={'vision':'existing'};config.write_text(json.dumps(cfg))
                self.assertEqual(boot.prepare(data,template)['ready_profiles'],['film'])
                template.write_text(json.dumps({'model_revisions':[{'revision':'b'}]}))
                self.assertEqual(boot.prepare(data,template)['ready_profiles'],[])
    def test_refuse_unexpected_weights(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);comfy=root/'comfy';(comfy/'models').mkdir(parents=True)
            (comfy/'models/weight').write_bytes(b'0'*(1024*1024+1))
            template=root/'template';template.write_text('{}')
            with patch.multiple(boot,COMFY=comfy,CONFIG=root/'config'):
                with self.assertRaisesRegex(RuntimeError,'Unexpected baked'):boot.prepare(root/'data',template)
            self.assertTrue((comfy/'models/weight').exists())

if __name__=='__main__':unittest.main()
