"""Dependency-free source validation. No downloads, image builds, or account access."""
import ast,hashlib,json,subprocess,sys
from pathlib import Path

def main():
    root=Path(__file__).resolve().parents[1]
    manifest=json.loads((root/'PACKAGE_SHA256.json').read_text())
    for name,expected in manifest.items():
        path=(root/name).resolve()
        if not path.is_relative_to(root.resolve()):raise RuntimeError('Unsafe manifest path')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise RuntimeError('Package hash mismatch: '+name)
    for path in root.rglob('*.py'):ast.parse(path.read_text(),filename=str(path))
    for name in ('01_Series_and_Movie.json','02_Motion_and_Product.json'):
        workflow=json.loads((root/'workflows'/name).read_text());assert workflow['nodes']
    for name in ('build.sh','post_start.sh'):subprocess.run(['bash','-n',str(root/'runpod'/name)],check=True)
    for test in ('test_boot.py','test_setup_guards.py'):subprocess.run([sys.executable,str(root/'runpod'/test)],check=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-s',str(root/'tests'),'-p','test_downloads.py'],check=True)
    print('PASS: package hashes, Python syntax, workflow JSON, shell syntax, boot/installer guards and mocked download tests. Docker build and real GPU inference were NOT tested.')

if __name__=='__main__':main()
