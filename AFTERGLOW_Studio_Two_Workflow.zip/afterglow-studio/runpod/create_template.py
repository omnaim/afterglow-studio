"""Create a private RunPod template only. Never creates or starts a Pod."""
import argparse,json,os,re,secrets,urllib.request
from pathlib import Path

def payload(image,profile,disk):
    if not re.fullmatch(r'[a-z0-9][a-z0-9._/-]+:[A-Za-z0-9_.-]+',image) or image.endswith(':latest'):
        raise ValueError('Provide a registry image with an explicit version tag, not latest.')
    return {'name':'AFTERGLOW Studio — Auto Download','imageName':image,'category':'NVIDIA','isPublic':False,'isServerless':False,
            'containerDiskInGb':disk,'volumeInGb':0,'volumeMountPath':'/workspace','ports':['8188/http','8888/http','22/tcp'],
            'env':{'AFTERGLOW_PROFILE':profile,'AFTERGLOW_AUTODOWNLOAD':'1','AFTERGLOW_DATA':'/workspace/afterglow',
                   'JUPYTER_PASSWORD':secrets.token_urlsafe(24)},
            'readme':'AFTERGLOW preinstalled software; automatic model downloads at boot. No persistent volume. Models, inputs and outputs are lost when ephemeral storage is destroyed. Open ComfyUI 8188; use the model download panel to monitor readiness. Export outputs before termination.'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',default='tylersabrin/afterglow-studio:1.0.0');p.add_argument('--profile',choices=['film','design','graphics','full'],default='full');p.add_argument('--disk-gb',type=int,default=500);p.add_argument('--apply',action='store_true')
    a=p.parse_args();body=payload(a.image,a.profile,a.disk_gb)
    if not a.apply:
        body['env']['JUPYTER_PASSWORD']='GENERATED_WHEN_APPLIED';print(json.dumps(body,indent=2));return
    token=os.environ.get('RUNPOD_API_KEY')
    if not token:raise SystemExit('Set RUNPOD_API_KEY in this terminal environment. Do not put it into source files.')
    req=urllib.request.Request('https://rest.runpod.io/v1/templates',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=60) as r:result=json.load(r)
    print('Private template created:',result['id'])
    print('No GPU Pod was started. Jupyter password is in your private template environment settings.')

if __name__=='__main__':main()
