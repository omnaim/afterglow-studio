"""Disk sinks keep all shot tensors out of the parent ComfyUI graph/cache."""
import subprocess
from pathlib import Path
import numpy as np
from PIL import Image
import folder_paths

def safe(root,name):
    root=Path(root).resolve();path=(root/name).resolve()
    if not path.is_relative_to(root):raise ValueError('Output path escapes configured directory.')
    path.parent.mkdir(parents=True,exist_ok=True);return path

class StudioWriteImage:
    @classmethod
    def INPUT_TYPES(cls):return {'required':{'images':('IMAGE',),'relative_path':('STRING',{'default':'studio/keyframe.png'})}}
    RETURN_TYPES=('STRING',);FUNCTION='save';CATEGORY='Afterglow Studio/Internal';OUTPUT_NODE=True
    def save(self,images,relative_path):
        p=safe(folder_paths.get_input_directory(),relative_path)
        if p.suffix.lower()!='.png':raise ValueError('Keyframes must use PNG.')
        arr=(images[0].detach().cpu().numpy().clip(0,1)*255).round().astype(np.uint8)
        tmp=p.with_suffix('.tmp.png');Image.fromarray(arr).save(tmp);tmp.replace(p)
        return (str(p),)

class StudioWriteFrames:
    @classmethod
    def INPUT_TYPES(cls):return {'required':{'images':('IMAGE',),'relative_path':('STRING',{'default':'studio/shot.mkv'}),'duration':('INT',{'default':6,'min':4,'max':15}),'fps':('INT',{'default':24,'min':24,'max':24})}}
    RETURN_TYPES=('STRING',);FUNCTION='save';CATEGORY='Afterglow Studio/Internal';OUTPUT_NODE=True
    def save(self,images,relative_path,duration,fps):
        p=safe(folder_paths.get_output_directory(),relative_path)
        if p.suffix.lower()!='.mkv':raise ValueError('Intermediates use MKV.')
        count=duration*fps
        if images.shape[0]<count:raise ValueError('Model output is shorter than the requested shot; refusing a freeze-frame extension.')
        h,w=images.shape[1:3];tmp=p.with_suffix('.tmp.mkv')
        log=p.with_suffix('.encode.log')
        with log.open('wb') as err:
            process=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r',str(fps),'-i','pipe:0','-an','-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv444p','-c:v','ffv1','-level','3','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(tmp)],stdin=subprocess.PIPE,stderr=err)
            try:
                for frame in images[:count]:
                    process.stdin.write((frame[...,:3].detach().cpu().numpy().clip(0,1)*255).round().astype(np.uint8).tobytes())
                process.stdin.close()
                if process.wait():raise RuntimeError(log.read_text()[-3000:])
            except BaseException:
                process.kill();process.wait();tmp.unlink(missing_ok=True);raise
        tmp.replace(p);return (str(p),)

MAPPINGS={'StudioWriteImage':StudioWriteImage,'StudioWriteFrames':StudioWriteFrames}
