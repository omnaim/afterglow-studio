"""Local file intake, constrained production plans and deterministic audio editing."""
import hashlib
import io
import json
import math
import re
import subprocess
import unicodedata
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageOps


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def atomic_json(path, data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)


def ingest(source, destination):
    """Read images directly; extract native PDF image pixels and page renders/text."""
    source=Path(source);destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    assets=[];pages=[];texts=[]
    def add(image, kind, page=None, boxes=None):
        if len(assets)>=144:raise ValueError('Storyboard exceeds the 144 visual-asset limit.')
        ident=f'A{len(assets):03d}'
        image=image.convert('RGBA') if 'A' in image.getbands() else image.convert('RGB');path=destination/f'{ident}.png'
        buffer=io.BytesIO();image.save(buffer,format='PNG')
        partial=path.with_suffix('.part');partial.write_bytes(buffer.getvalue());partial.replace(path)
        assets.append({'id':ident,'path':str(path.resolve()),'kind':kind,'page':page,
                       'width':image.width,'height':image.height,'placements':boxes or []})
        return ident
    if source.suffix.lower()=='.pdf':
        import fitz
        with fitz.open(source) as doc:
            if doc.needs_pass:raise ValueError('Password-protected PDFs are not supported.')
            if not 1<=len(doc)<=16:raise ValueError('Use a storyboard PDF with 1–16 pages.')
            seen={}
            for i,page in enumerate(doc):
                if len(assets)>144:raise ValueError('Storyboard has too many images; limit it to 144 visual assets.')
                text=page.get_text('text');texts.append(f'PAGE {i+1}:\n{text}')
                scale=min(2.0,1920/max(page.rect.width,page.rect.height))
                pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
                ident=add(Image.frombytes('RGB',[pix.width,pix.height],pix.samples),'page',i+1)
                pages.append(ident)
                for item in page.get_images(full=True):
                    xref=item[0]
                    if xref in seen:continue
                    if item[2]<96 or item[3]<96:continue
                    # Combine PDF soft masks when present; discard layout in favor of original image pixels.
                    pix=fitz.Pixmap(doc,xref)
                    if item[1]:
                        try:pix=fitz.Pixmap(pix,fitz.Pixmap(doc,item[1]))
                        except (ValueError,RuntimeError):pass
                    if pix.colorspace is None:continue
                    if pix.colorspace.n!=3:pix=fitz.Pixmap(fitz.csRGB,pix)
                    raw=Image.frombytes('RGBA' if pix.alpha else 'RGB',[pix.width,pix.height],pix.samples)
                    if pix.alpha:
                        raw=raw.convert('RGBA')
                    boxes=[[r.x0/page.rect.width*1000,r.y0/page.rect.height*1000,r.x1/page.rect.width*1000,r.y1/page.rect.height*1000] for r in page.get_image_rects(xref)]
                    seen[xref]=add(raw,'embedded_original',i+1,boxes)
    elif source.suffix.lower() in ['.png','.jpg','.jpeg','.webp']:
        with Image.open(source) as raw:
            raw.load();im=ImageOps.exif_transpose(raw).convert('RGBA')
        pages.append(add(im,'source_image',1))
    else:raise ValueError('Upload PDF, PNG, JPEG or WebP.')
    text='\n\n'.join(texts)
    if len(text)>150000:raise ValueError('Storyboard text exceeds 150,000 characters; use a shorter document.')
    sheets=[]
    for start in range(0,len(assets),24):
        block=assets[start:start+24];canvas=Image.new('RGB',(1440,math.ceil(len(block)/6)*210),(18,20,20));draw=ImageDraw.Draw(canvas)
        for j,asset in enumerate(block):
            with Image.open(asset['path']) as im:
                thumb=ImageOps.contain(im.convert('RGB'),(228,174))
                x=(j%6)*240;y=(j//6)*210
                canvas.paste(thumb,(x+(240-thumb.width)//2,y+24))
                draw.text((x+6,y+3),f'{asset["id"]} {asset["width"]}x{asset["height"]}',fill='white')
        path=destination/f'catalog_{start//24:02d}.jpg';canvas.save(path,quality=94);sheets.append(str(path.resolve()))
    result={'source':str(source.resolve()),'source_sha256':sha256(source),'assets':assets,
            'page_ids':pages,'page_images':[a['path'] for a in assets if a['id'] in pages],
            'contact_sheets':sheets,'text':text}
    atomic_json(destination/'intake.json',result);return result


def parse_json(text):
    # The model is not permitted to emit executable instructions; decode JSON only.
    text=re.sub(r'<think>.*?</think>','',text,flags=re.S).strip()
    text=re.sub(r'^```(?:json)?\s*','',text);text=re.sub(r'\s*```$','',text)
    try:return json.loads(text)
    except json.JSONDecodeError:
        start=text.find('{')
        if start<0:raise ValueError('Local planner did not return a JSON object.')
        return json.JSONDecoder().raw_decode(text[start:])[0]


def normalize_arabic(text):
    text=unicodedata.normalize('NFKC',text)
    text=re.sub(r'[\u064b-\u065f\u0670\u0640]','',text)
    return re.sub(r'[^\u0621-\u064a]','',text.translate(str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ى':'ي','ة':'ه'})))


def character_error_rate(reference,hypothesis):
    a,b=normalize_arabic(reference),normalize_arabic(hypothesis)
    row=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        new=[i]
        for j,y in enumerate(b,1):new.append(min(new[-1]+1,row[j]+1,row[j-1]+(x!=y)))
        row=new
    return row[-1]/max(1,len(a))


def ffmpeg(args):
    r=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error',*args],capture_output=True)
    if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace')[-5000:])
    return r.stdout


def audio_48k(path):
    b=ffmpeg(['-i',str(path),'-vn','-ac','2','-ar','48000','-f','f32le','pipe:1'])
    return np.frombuffer(b,dtype='<f4').reshape(-1,2).copy()


def write_wav(path,audio):
    import wave
    pcm=np.rint(np.clip(audio,-1,1)*32767).astype('<i2')
    with wave.open(str(path),'wb') as f:
        f.setnchannels(2);f.setsampwidth(2);f.setframerate(48000);f.writeframes(pcm.tobytes())


