"""HunyuanVideo-Foley XXL over the actual selected shots; no music model."""
import argparse
import json
import sys
from pathlib import Path

from common import atomic_json


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--request',type=Path,required=True)
    a=parser.parse_args();job=json.loads(a.request.read_text());config=job['config']
    repo=Path(config['repos']['foley']);sys.path.insert(0,str(repo))
    import torch
    import torchaudio
    import soundfile as sf
    from silero_vad import load_silero_vad, get_speech_timestamps
    from hunyuanvideo_foley.utils.model_utils import load_model
    from infer import infer
    # Same API as the pinned upstream infer.py; avoid its optional video re-mux.
    model,cfg=load_model(config['models']['foley'],str(repo/'configs/hunyuanvideo-foley-xxl.yaml'),torch.device('cuda'),enable_offload=False,model_size='xxl')
    output=Path(job['directory']);output.mkdir(parents=True,exist_ok=True);paths=[];checks={}
    vad=load_silero_vad()
    for i,(shot,video) in enumerate(zip(job['plan']['shots'],job['videos'])):
        prompt=shot['foley_prompt']+' Only real location ambience and restrained physical Foley. No music, speech, dialogue, voices, singing or melodic tones.'
        attempts=[]
        for take in range(3):
            torch.manual_seed(job['seed']+i*100+take)
            audio,sr=infer(video,prompt,model,cfg,guidance_scale=4.5,num_inference_steps=50,neg_prompt='music, speech, dialogue, voices, singing, harsh noise, clipping')
            signal=audio.detach().float().cpu()
            if signal.ndim==1:signal=signal.unsqueeze(0)
            mono=torchaudio.functional.resample(signal.mean(dim=0),sr,16000)
            stamps=get_speech_timestamps(mono,vad,sampling_rate=16000,threshold=0.9,min_speech_duration_ms=250)
            speech_seconds=sum(s['end']-s['start'] for s in stamps)/16000
            attempts.append({'take':take,'detected_speech_seconds':speech_seconds})
            if speech_seconds<=0.30:break
        else:
            atomic_json(output/f'shot_{i+1:02d}_voice_rejections.json',attempts)
            raise RuntimeError(f'Foley for shot {i+1} remained speech-like after 3 attempts; refusing to mix unintended non-Arabic voices.')
        path=output/f'shot_{i+1:02d}_foley.wav';sf.write(path,signal.transpose(0,1).numpy(),sr);paths.append(str(path.resolve()))
        checks[str(i+1)]=attempts
    atomic_json(job['output'],paths)
    atomic_json(output/'voice_activity_checks.json',checks)


if __name__=='__main__':main()
