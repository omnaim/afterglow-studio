"""BiRefNet HR supplies alpha only; original RGB artwork is preserved."""
import argparse,json
from pathlib import Path
from common import atomic_json

def main():
    p=argparse.ArgumentParser();p.add_argument('--request',type=Path,required=True);a=p.parse_args();job=json.loads(a.request.read_text())
    import torch
    from PIL import Image
    from torchvision import transforms
    from transformers import AutoModelForImageSegmentation
    model=None;results={}
    for name,path in job['assets'].items():
        im=Image.open(path).convert('RGBA')
        if im.getchannel('A').getextrema()==(255,255):
            if model is None:
                model=AutoModelForImageSegmentation.from_pretrained(job['config']['models']['segmentation'],trust_remote_code=True,local_files_only=True).eval().to('cuda').half()
            transform=transforms.Compose([transforms.Resize((2048,2048)),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
            with torch.inference_mode():mask=model(transform(im.convert('RGB')).unsqueeze(0).to('cuda').half())[-1].sigmoid().cpu()[0].squeeze()
            alpha=transforms.ToPILImage()(mask).resize(im.size,Image.Resampling.LANCZOS)
            if alpha.getextrema()[1]<100:raise RuntimeError('Product segmentation found no foreground; inspect the selected source crop.')
            im.putalpha(alpha)
        box=im.getchannel('A').getbbox()
        if not box:raise RuntimeError('Empty product alpha.')
        im=im.crop(box);dest=Path(job['directory'])/(name+'.png');dest.parent.mkdir(parents=True,exist_ok=True);im.save(dest);results[name]=str(dest.resolve())
    atomic_json(job['output'],results)

if __name__=='__main__':main()
