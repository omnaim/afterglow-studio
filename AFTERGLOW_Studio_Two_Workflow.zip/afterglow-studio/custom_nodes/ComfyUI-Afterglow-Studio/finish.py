"""Deterministic typography, product layers, audio mix and editorial delivery."""
import json,math,subprocess,tempfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageOps,features
from common import ffmpeg,audio_48k,write_wav,atomic_json,parse_json

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))

def checked_video(path,duration,width=None,height=None):
    p=probe(path);v=next(s for s in p['streams'] if s['codec_type']=='video')
    if v['r_frame_rate']!='24/1':raise ValueError('Expected 24 fps editorial footage.')
    if abs(float(p['format']['duration'])-duration)>.05:raise ValueError('Unexpected rendered duration.')
    if width and (v['width'],v['height'])!=(width,height):raise ValueError('Unexpected frame size.')
    return p

def crop(ref,intake,destination):
    asset=next(a for a in intake['assets'] if a['id']==ref['asset'])
    with Image.open(asset['path']) as im:
        b=ref['bbox'];im=im.crop(tuple(round(v*(im.width if i%2==0 else im.height)/1000) for i,v in enumerate(b)))
        Path(destination).parent.mkdir(parents=True,exist_ok=True);im.save(destination)
    return str(Path(destination).resolve())

def framed(source,destination,width,height):
    with Image.open(source) as im:
        # Cover is a layout reference; full uncropped subject anchors remain separate.
        im=ImageOps.fit(im.convert('RGB'),(width,height),method=Image.Resampling.LANCZOS)
        im.save(destination)
    return str(destination)

def contact_sheet(video,destination,duration):
    with tempfile.TemporaryDirectory() as temp:
        ffmpeg(['-y','-i',str(video),'-vf',f'fps={8/duration},scale=240:240:force_original_aspect_ratio=decrease,pad=240:240:(ow-iw)/2:(oh-ih)/2','-frames:v','8',str(Path(temp)/'%02d.png')])
        canvas=Image.new('RGB',(960,540),(12,14,18));draw=ImageDraw.Draw(canvas)
        for i,p in enumerate(sorted(Path(temp).glob('*.png'))):
            x=(i%4)*240;y=(i//4)*270;canvas.paste(Image.open(p),(x,y+25));draw.text((x+8,y+5),f'{i*duration/8:.2f}s',fill='white')
        canvas.save(destination)
    return str(destination)

def font_path():
    paths=['/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
    for p in paths:
        if Path(p).is_file():return p
    raise RuntimeError('Install fonts-noto-core or fonts-dejavu-core for Arabic typography.')

def text_card(value,width,size,color):
    if not value:return Image.new('RGBA',(width,1))
    if not features.check('raqm'):raise RuntimeError('Pillow must have RAQM for correctly joined RTL Arabic text.')
    font=ImageFont.truetype(font_path(),size);scratch=Image.new('RGBA',(width,1));d=ImageDraw.Draw(scratch)
    lines=[];line=''
    for word in value.split():
        test=(line+' '+word).strip()
        if d.textlength(test,font=font,direction='rtl')>width-12 and line:lines.append(line);line=word
        else:line=test
    if line:lines.append(line)
    if any(d.textlength(x,font=font,direction='rtl')>width-12 for x in lines):
        if size<12:raise ValueError('Text cannot fit the safe area.')
        return text_card(value,width,size-2,color)
    line_h=round(size*1.55);result=Image.new('RGBA',(width,line_h*len(lines)));draw=ImageDraw.Draw(result)
    for i,line in enumerate(lines):draw.text((width/2,i*line_h),line,font=font,fill=color,anchor='mt',direction='rtl',language='ar',stroke_width=0)
    return result

def ease(x):
    x=max(0,min(1,x));return 1-(1-x)**3

def graphic_assets(shot,bible,assets,w,h):
    pal=bible['brand']['palette'];fg=pal[1];accent=pal[2]
    hs=int(min(w,h)*.062);bs=int(min(w,h)*.028)
    headline=text_card(shot['layout']['headline_ar'],int(w*.78),hs,fg)
    body=text_card(shot['layout']['body_ar'],int(w*.76),bs,fg)
    while headline.height>h*.18 and hs>12:
        hs-=2;headline=text_card(shot['layout']['headline_ar'],int(w*.78),hs,fg)
    while body.height>h*.13 and bs>10:
        bs-=2;body=text_card(shot['layout']['body_ar'],int(w*.76),bs,fg)
    if headline.height>h*.18 or body.height>h*.13:raise ValueError('Shorten graphic copy to fit the protected title areas.')
    product=Image.open(assets['product']).convert('RGBA') if assets.get('product') else None
    logo=Image.open(assets['logo']).convert('RGBA') if assets.get('logo') else None
    product_top=max(h*.28,h*.155+headline.height)
    if product:product=ImageOps.contain(product,(int(w*.62),int(h*.70-product_top)),Image.Resampling.LANCZOS)
    if logo:logo=ImageOps.contain(logo,(int(w*.22),int(h*.07)),Image.Resampling.LANCZOS)
    return {'headline':headline,'body':body,'product':product,'logo':logo,'accent':accent,'palette':pal,'product_center_y':(product_top+h*.70)/2}

def graphic_frame(shot,prepared,w,h,frame,fps=24):
    t=frame/fps;duration=shot['duration'];enter=ease(t/.75);exit_=ease((duration-t)/.35)
    im=Image.new('RGBA',(w,h));draw=ImageDraw.Draw(im);accent=prepared['accent']
    # Decorative shapes follow a coherent grid; all pixels are deterministic.
    r=min(w,h)*.36;cx=w*.5;cy=h*.50;phase=t*14
    color=tuple(int(accent[i:i+2],16) for i in (1,3,5))
    for j in range(3):
        rr=r*(1+j*.09);draw.arc((cx-rr,cy-rr,cx+rr,cy+rr),phase+j*120,phase+j*120+68,fill=(*color,int(90*enter)),width=max(1,int(w*.002)))
    line_y=int(h*.735);draw.line((w*.12,line_y,w*(.12+.76*enter),line_y),fill=(*color,150),width=max(1,int(w*.002)))
    # Keep decorative strokes out of the protected text zones in every ratio.
    draw.rectangle((0,0,w,int(h*.145+prepared['headline'].height)),fill=(0,0,0,0))
    draw.rectangle((0,int(h*.76),w,int(h*.915)),fill=(0,0,0,0))
    product=prepared['product'];motion=shot['layout']['motion']
    if product:
        scale=1.0+(.045*math.sin(t*.9) if motion=='float' else .09*t/duration if motion in ('push','detail') else 0)
        item=product.resize((max(1,int(product.width*scale)),max(1,int(product.height*scale))),Image.Resampling.LANCZOS)
        x=int((w-item.width)/2);y=int(prepared['product_center_y']-item.height/2)
        if motion=='slide':x+=int((1-enter)*w*.32)
        else:y+=int((1-enter)*h*.06+math.sin(t*.8)*h*.007)
        shadow=Image.new('RGBA',(w,h));sd=ImageDraw.Draw(shadow)
        sd.ellipse((w*.25,h*.68,w*.75,h*.71),fill=(0,0,0,100));im.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(w*.018)))
        if motion=='reveal':
            alpha=item.getchannel('A');mask=Image.new('L',item.size);ImageDraw.Draw(mask).rectangle((0,0,item.width*enter,item.height),fill=255)
            import PIL.ImageChops
            item.putalpha(PIL.ImageChops.multiply(alpha,mask))
        im.alpha_composite(item,(x,y))
    head=prepared['headline'];body=prepared['body']
    hy=int(h*.12+(1-enter)*h*.025)
    if motion=='type' and t<1:
        # Reveal a complete shaped Arabic line spatially; never break joining.
        mask=Image.new('L',head.size);ImageDraw.Draw(mask).rectangle((head.width*(1-ease(t)),0,head.width,head.height),fill=255)
        head=head.copy()
        import PIL.ImageChops
        head.putalpha(PIL.ImageChops.multiply(head.getchannel('A'),mask))
    im.alpha_composite(head,((w-head.width)//2,hy))
    im.alpha_composite(body,((w-body.width)//2,int(h*.77)))
    if prepared['logo']:
        logo=prepared['logo'];im.alpha_composite(logo,((w-logo.width)//2,int(h*.035)))
    if exit_<1:im.putalpha(im.getchannel('A').point(lambda v:int(v*exit_)))
    return im

def render_design(shot,bible,assets,background,destination,w,h,overlay_path=None):
    prepared=graphic_assets(shot,bible,assets,w,h);n=shot['duration']*24
    decoder=subprocess.Popen(['ffmpeg','-v','error','-i',str(background),'-vf',f'scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},fps=24','-f','rawvideo','-pix_fmt','rgb24','pipe:1'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    dest=Path(destination);tmp=dest.with_suffix('.tmp.mkv')
    encode=['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{w}x{h}','-framerate','24','-i','pipe:0','-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv444p','-c:v','ffv1','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(tmp)]
    proc=subprocess.Popen(encode,stdin=subprocess.PIPE);overlay=None
    if overlay_path:
        overlay=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size',f'{w}x{h}','-framerate','24','-i','pipe:0','-c:v','prores_ks','-profile:v','4','-pix_fmt','yuva444p10le',str(overlay_path)],stdin=subprocess.PIPE)
    try:
        for i in range(n):
            raw=decoder.stdout.read(w*h*3)
            if len(raw)!=w*h*3:raise RuntimeError('Background ended before the design timeline.')
            bg=Image.frombytes('RGB',(w,h),raw).convert('RGBA');layer=graphic_frame(shot,prepared,w,h,i)
            bg.alpha_composite(layer);proc.stdin.write(bg.convert('RGB').tobytes())
            if overlay:overlay.stdin.write(layer.tobytes())
        proc.stdin.close()
        if proc.wait():raise RuntimeError('Design encoder failed.')
        if overlay:
            overlay.stdin.close()
            if overlay.wait():raise RuntimeError('Alpha overlay encoder failed.')
        tmp.replace(dest)
    finally:
        for p in [decoder,proc,overlay]:
            if p is not None and p.poll() is None:p.kill();p.wait()
            if p is not None:
                for stream in [p.stdin,p.stdout]:
                    if stream is not None and not stream.closed:stream.close()
    checked_video(dest,shot['duration'],w,h)

def still_background(image,destination,duration,w,h):
    # Subtle deterministic push for graphic layouts; all foreground animation is separate.
    ffmpeg(['-y','-loop','1','-i',str(image),'-vf',f'scale={w*2}:{h*2}:force_original_aspect_ratio=increase,crop={w*2}:{h*2},zoompan=z=1.025+0.025*on/{duration*24}:x=iw/2-iw/zoom/2:y=ih/2-ih/zoom/2:d=1:s={w}x{h}:fps=24,format=yuv444p','-frames:v',str(duration*24),'-an','-c:v','ffv1',str(destination)])

def design_sfx(shots,directory,seed):
    rng=np.random.default_rng(seed);result=[];directory=Path(directory);directory.mkdir(exist_ok=True)
    for s in shots:
        a=np.zeros((s['duration']*48000,2),np.float32);n=14400
        noise=rng.normal(0,.045,(n,2)).astype(np.float32)
        # Short broadband movement sound, with no tonal sequence or musical layer.
        smoothed=np.cumsum(noise,axis=0);smoothed[16:]-=smoothed[:-16].copy();smoothed/=16
        a[4800:4800+n]=smoothed*np.sin(np.linspace(0,math.pi,n))[:,None]
        p=directory/f'{s["index"]:04d}.wav';write_wav(p,a);result.append(str(p))
    return result

def mix_audio(plan,foley,speech,destination):
    sr=48000;duration=sum(s['duration'] for s in plan['shots']);mix=np.zeros((duration*sr,2),np.float32);stems={};subtitles=[];offset=0
    for s,path in zip(plan['shots'],foley):
        n=s['duration']*sr;a=audio_48k(path)[:n];rms=float(np.sqrt(np.mean(a*a))) if len(a) else 0
        if rms>1e-6:a*=min(6,10**(-29/20)/rms)
        fade=min(sr//10,len(a)//2)
        if fade:a[:fade]*=np.linspace(0,1,fade)[:,None];a[-fade:]*=np.linspace(1,0,fade)[:,None]
        mix[offset:offset+len(a)]+=a
        if s.get('speech'):
            voice=audio_48k(speech[str(s['index'])])[:n];gate=np.mean(np.abs(voice),axis=1)>.003
            mix[offset:offset+len(voice)]*=.32
            # Preserve the original speech waveform gain: independently normalizing
            # every line can destroy an actor's intended dynamic delivery.
            mix[offset:offset+len(voice)]+=voice
            audible=np.flatnonzero(gate)
            subtitles.append({'start':offset/sr+(audible[0]/sr if len(audible) else .3),'end':offset/sr+(min(n/sr,audible[-1]/sr+.12) if len(audible) else n/sr-.2),'text_ar':s['speech']['text_ar']})
        offset+=n
    mix[-sr:]*=np.linspace(1,0,sr)[:,None]
    destination=Path(destination);raw=destination.with_name('mix_unmastered.wav');write_wav(raw,mix)
    if float(np.max(np.abs(mix)))<1e-7:write_wav(destination,mix);return subtitles
    r=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-f','null','-'],capture_output=True,check=True)
    rawlog=r.stderr.decode();d=parse_json(rawlog[rawlog.rfind('{'):])
    if not all(math.isfinite(float(d[k])) for k in ['input_i','input_tp','input_lra','input_thresh','target_offset']):raise RuntimeError('Invalid audio loudness measurement.')
    filt=f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={d['input_i']}:measured_TP={d['input_tp']}:measured_LRA={d['input_lra']}:measured_thresh={d['input_thresh']}:offset={d['target_offset']}:linear=true"
    ffmpeg(['-y','-i',str(raw),'-af',filt,'-ar','48000','-ac','2','-t',str(duration),str(destination)])
    atomic_json(destination.with_suffix('.json'),{'target_lufs':-16,'target_true_peak_db':-1.5,'first_pass':d,'music_model':False})
    return subtitles

def timecode(frames):
    sec,f=divmod(frames,24);minute,s=divmod(sec,60);h,m=divmod(minute,60);return f'{h:02d}:{m:02d}:{s:02d}:{f:02d}'

def export_edit(plan,clips,subtitles,directory):
    p=Path(directory);timeline=[];cursor=0;edl=['TITLE: AFTERGLOW STUDIO','FCM: NON-DROP FRAME','']
    for i,(s,clip) in enumerate(zip(plan['shots'],clips),1):
        frames=s['duration']*24;timeline.append({'index':i,'start_frame':cursor,'frames':frames,'file':str(clip),'speech':s.get('speech'),'layout':s['layout']})
        edl += [f'{i:03d}  S{i:06d} V     C        00:00:00:00 {timecode(frames)} {timecode(cursor)} {timecode(cursor+frames)}',f'* FROM CLIP NAME: {Path(clip).name}',f'* SOURCE FILE: {clip}',''];cursor+=frames
    (p/'edit.edl').write_text('\n'.join(edl));atomic_json(p/'timeline.json',{'fps':24,'frames':cursor,'clips':timeline})
    def st(t):
        ms=round(t*1000);s,ms=divmod(ms,1000);m,s=divmod(s,60);h,m=divmod(m,60);return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'
    (p/'Arabic.srt').write_text('\n\n'.join(f'{i}\n{st(s["start"])} --> {st(s["end"])}\n{s["text_ar"]}' for i,s in enumerate(subtitles,1)),encoding='utf-8')

def master(clips,audio,destination,w,h,duration,mezzanine=False):
    p=Path(destination);work=p.parent
    # Safe relative links keep arbitrary user path characters out of ffconcat syntax.
    join=work/'concat';join.mkdir(exist_ok=True);lines=[]
    for i,clip in enumerate(clips):
        link=join/f'{i:04d}.mkv'
        if link.is_symlink():link.unlink()
        link.symlink_to(Path(clip).resolve());lines.append(f"file '{link.name}'")
    (join/'list.txt').write_text('\n'.join(lines))
    filters=f'scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},setsar=1,fps=24,fade=t=out:st={duration-1}:d=1'
    command=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','1','-i','list.txt','-i',str(Path(audio).resolve()),'-map','0:v:0','-map','1:a:0','-vf',filters,'-frames:v',str(duration*24),'-t',str(duration),'-color_range','tv','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709']
    temp=p.with_name(p.stem+'.partial.mp4')
    subprocess.run(command+['-c:v','libx264','-preset','slow','-crf','16','-pix_fmt','yuv420p','-c:a','aac','-b:a','320k','-ar','48000','-movflags','+faststart',str(temp.resolve())],cwd=join,check=True);temp.replace(p)
    checked_video(p,duration,w,h)
    if mezzanine:
        out=p.with_suffix('.mov');tmp=out.with_name(out.stem+'.partial.mov')
        subprocess.run(command+['-c:v','prores_ks','-profile:v','3','-pix_fmt','yuv422p10le','-c:a','pcm_s24le','-ar','48000',str(tmp.resolve())],cwd=join,check=True);tmp.replace(out)
    return str(p.resolve())
