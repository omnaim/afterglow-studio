"""Queue one shot at a time; preflight against the user's real /object_info schema.

Uses Python's standard library. Run --help. No model loading in this process.
"""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path


def request(base, path, payload=None):
    data = json.dumps(payload).encode() if payload is not None else None
    headers = {'Content-Type':'application/json'}
    req = urllib.request.Request(base.rstrip('/')+path, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'ComfyUI HTTP {error.code}: {error.read().decode(errors="replace")[:3000]}') from error


def preflight(prompt, info):
    """Check actual node schemas, installed model names and every socket type."""
    issues=[]
    for number,node in prompt.items():
        kind=node['class_type'];spec=info.get(kind)
        if not spec:
            issues.append(f'{number}: node {kind} is missing');continue
        required=dict(spec['input'].get('required',{}))
        allowed={**required,**spec['input'].get('optional',{})}
        # Native V3 autogrow sockets appear as dotted keys in API prompts.
        import re
        dynamic={'TextEncodeQwenImage21':{'images.image_':('IMAGE',16,1)},'MiniMaxH3ReferenceToVideo':{'ref_images.ref_image_':('IMAGE',9,0),'ref_audios.ref_audio_':('AUDIO',3,0)}}.get(kind,{})
        for prefix,(dtype,maximum,first) in dynamic.items():
            required.pop(prefix.split('.')[0],None)
            for k in node['inputs']:
                if k.startswith(prefix) and k[len(prefix):].isdigit() and first<=int(k[len(prefix):])<first+maximum:allowed[k]=(dtype,)
        for name in required:
            if name not in node['inputs']:
                issues.append(f'{number}/{kind}: required {name} missing')
        for name,value in node['inputs'].items():
            if name not in allowed:
                issues.append(f'{number}/{kind}: this installation does not support {name}; update the node pack');continue
            typ, *options=allowed[name]
            opts=options[0] if options else {}
            is_link=isinstance(value,list) and len(value)==2 and isinstance(value[0],str) and value[0] in prompt and isinstance(value[1],int)
            if is_link:
                upstream=info.get(prompt[value[0]]['class_type'])
                if upstream:
                    outputs=upstream['output']
                    if not 0 <= value[1] < len(outputs):
                        issues.append(f'{number}/{name}: nonexistent upstream output')
                    elif isinstance(typ,str) and typ not in ['*',outputs[value[1]]]:
                        issues.append(f'{number}/{name}: {outputs[value[1]]} cannot connect to {typ}')
            elif (kind=='LoadImage' and name=='image') or (kind=='LoadAudio' and name=='audio'):
                # The enum is a momentary server file list. The all stage creates
                # future keyframes after this preflight; disk checks happen below.
                pass
            elif isinstance(typ,list) and value not in typ:
                issues.append(f'{number}/{name}: {value!r} is not installed or is not an accepted option')
            elif isinstance(typ,str) and typ in ('INT','FLOAT') and isinstance(value,(int,float)):
                if ('min' in opts and value < opts['min']) or ('max' in opts and value > opts['max']):
                    issues.append(f'{number}/{name}: value {value} outside node range')
            elif isinstance(typ,str) and typ not in ['STRING','INT','FLOAT','BOOLEAN']:
                issues.append(f'{number}/{name}: expected socket link for {typ}')
    if issues:
        raise RuntimeError('Preflight failed:\n'+'\n'.join(issues))


def queue_and_wait(base,prompt,client_id,timeout):
    result=request(base,'/prompt',{'prompt':prompt,'client_id':client_id})
    if result.get('node_errors'):
        raise RuntimeError(json.dumps(result['node_errors'],indent=2))
    pid=result['prompt_id'];started=time.monotonic()
    print(f'Queued {pid}',flush=True)
    while time.monotonic()-started < timeout:
        history=request(base,'/history/'+urllib.parse.quote(pid))
        if pid in history:
            item=history[pid];status=item.get('status',{})
            messages=status.get('messages',[])
            failures=[m for m in messages if m[0] in ['execution_error','execution_interrupted']]
            if failures or status.get('status_str')=='error':
                raise RuntimeError('Render failed: '+json.dumps(failures or status,indent=2))
            if status.get('completed') or status.get('status_str')=='success':
                return item
        time.sleep(2)
    raise TimeoutError(f'Waiting exceeded {timeout}s. Job {pid} may still be running; inspect ComfyUI before retrying.')

