import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

function openModels(defaultProfile) {
  const dialog = document.createElement("dialog");
  dialog.style.cssText = "width:min(760px,90vw);background:#20232a;color:white;padding:24px;border:1px solid #777;border-radius:12px";
  const title = document.createElement("h2"); title.textContent = "AFTERGLOW · Model downloads";
  const note = document.createElement("p"); note.textContent = "First download is large: full native video/image weights alone are 156 GB, plus speech and planning models. Files stay on the server. Choose Graphics only if your workflow uses Graphic motion. No music model is installed.";
  const select = document.createElement("select");
  for (const [value, label] of [["film","Series / movie"],["design","Motion / product"],["graphics","Graphics only · no H3 video"],["full","Both production workflows"]]) {
    const option = document.createElement("option"); option.value=value; option.textContent=label;select.append(option);
  }
  select.value=defaultProfile;
  const download=document.createElement("button");download.textContent="Download / resume";
  const cancel=document.createElement("button");cancel.textContent="Stop download";
  const close=document.createElement("button");close.textContent="Close";
  const status=document.createElement("p");
  const log=document.createElement("pre");log.style.cssText="white-space:pre-wrap;max-height:42vh;overflow:auto;font-size:12px";
  async function refresh() {
    try {
      const response=await api.fetchApi("/afterglow-studio/models");if(!response.ok)throw Error(await response.text());
      const data=await response.json();
      status.textContent=data.running?"Downloading — you can close this panel safely.":`Ready: ${data.ready_profiles.join(", ") || "none"}. ${data.exit_code ? "Download stopped or failed; see log and resume." : ""}`;
      log.textContent=data.log;download.disabled=data.running;cancel.disabled=!data.running;
    } catch(error) {status.textContent=String(error);}
  }
  download.onclick=async()=>{try{download.disabled=true;const response=await api.fetchApi("/afterglow-studio/models",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({profile:select.value})});if(!response.ok)throw Error(await response.text());await refresh();}catch(error){status.textContent=String(error);download.disabled=false;}};
  cancel.onclick=async()=>{await api.fetchApi("/afterglow-studio/models/cancel",{method:"POST"});await refresh();};
  close.onclick=()=>dialog.close();
  dialog.append(title,note,select,download,cancel,close,status,log);document.body.append(dialog);dialog.showModal();
  const timer=setInterval(refresh,2000);dialog.addEventListener("close",()=>{clearInterval(timer);dialog.remove();},{once:true});refresh();
}
app.registerExtension({name:"Afterglow.Studio.Models",async beforeRegisterNodeDef(nodeType,nodeData){
  if(!["StudioFilm","StudioDesign"].includes(nodeData.name))return;
  const previous=nodeType.prototype.onNodeCreated;
  nodeType.prototype.onNodeCreated=function(){previous?.apply(this,arguments);this.addWidget("button","Download / resume models",null,()=>openModels(nodeData.name==="StudioFilm"?"film":"design"),{serialize:false});};
}});
