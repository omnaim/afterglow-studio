import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

app.registerExtension({
  name: "Afterglow.Studio",
  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name === "StudioSource") {
      const original = nodeType.prototype.onNodeCreated;
      nodeType.prototype.onNodeCreated = function () {
        original?.apply(this, arguments);
        this.addWidget("button", "Upload PDF / image", null, () => {
          const picker = document.createElement("input");
          picker.type = "file";
          picker.accept = ".pdf,.png,.jpg,.jpeg,.webp";
          picker.onchange = async () => {
            const file = picker.files?.[0];
            if (!file) return;
            const form = new FormData();
            form.append("file", file);
            try {
              const response = await api.fetchApi("/afterglow-studio/upload", { method: "POST", body: form });
              const data = await response.json();
              if (!response.ok) throw new Error(data.error || "Upload failed");
              const widget = this.widgets.find(w => w.name === "source_file");
              if (widget) {
                const values = Array.isArray(widget.options.values) ? widget.options.values : [];
                widget.options.values = [...new Set([...values, data.name])];
                widget.value = data.name;
              }
              this.title = `Storyboard: ${data.original_name}`;
              app.graph.setDirtyCanvas(true, true);
            } catch (error) {
              app.extensionManager?.toast?.add({ severity: "error", summary: "Afterglow upload", detail: String(error.message), life: 12000 });
              if (!app.extensionManager?.toast) alert(error.message);
            }
          };
          picker.click();
        }, { serialize: false });
      };
    }
    if (["StudioFilm", "StudioDesign"].includes(nodeData.name)) {
      const original = nodeType.prototype.onNodeCreated;
      nodeType.prototype.onNodeCreated = function () {
        original?.apply(this, arguments);
        const status = this.addWidget("text", "progress", "Ready — upload a file and Run", () => {}, { serialize: false });
        status.disabled = true;
      };
      const originalExecuted = nodeType.prototype.onExecuted;
      nodeType.prototype.onExecuted = function (message) {
        originalExecuted?.apply(this, arguments);
        const media = message.studio_video?.[0];
        if (!media) return;
        if (!this.afterglowVideo) {
          const video = document.createElement("video");
          video.controls = true;
          video.playsInline = true;
          video.preload = "metadata";
          video.style.cssText = "width:100%;height:100%;object-fit:contain;background:#111;";
          this.addDOMWidget("finished_film", "video", video, { serialize: false });
          this.afterglowVideo = video;
          this.setSize([Math.max(this.size[0], 480), 1040]);
        }
        const query = new URLSearchParams(media);
        this.afterglowVideo.src = api.apiURL(`/view?${query.toString()}`);
        app.graph?.setDirtyCanvas(true, true);
      };
    }
  },
  setup() {
    api.addEventListener("afterglow.studio.progress", event => {
      const node = app.graph?.getNodeById(Number(event.detail.node_id));
      const widget = node?.widgets?.find(w => w.name === "progress");
      if (widget) widget.value = `${event.detail.stage}: ${event.detail.text}`;
      app.graph?.setDirtyCanvas(true, true);
    });
  }
});
