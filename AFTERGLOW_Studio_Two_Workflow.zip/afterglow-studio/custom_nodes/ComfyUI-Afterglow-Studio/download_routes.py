"""Fixed-command local model manager; no user-supplied URLs or shell commands."""
import json
import os
import signal
import subprocess
from pathlib import Path
from aiohttp import web
from server import PromptServer

HERE=Path(__file__).resolve().parent
process=None
log_handle=None

def state():
    cfgpath=HERE/'config.json'
    cfg=json.loads(cfgpath.read_text()) if cfgpath.exists() else {}
    log=HERE/'model_download.log'
    tail=''
    if log.exists():
        with log.open('rb') as f:
            f.seek(max(0,log.stat().st_size-12000));tail=f.read().decode('utf-8',errors='replace')
    return {'configured':bool(cfg),'running':process is not None and process.poll() is None,
            'exit_code':process.poll() if process else None,'ready_profiles':cfg.get('ready_profiles',[]),'log':tail}

@PromptServer.instance.routes.get('/afterglow-studio/models')
async def status(request):return web.json_response(state())

@PromptServer.instance.routes.post('/afterglow-studio/models')
async def start(request):
    global process,log_handle
    # Reject cross-origin browser requests; use the host ComfyUI authentication/proxy.
    origin=request.headers.get('Origin')
    if origin:
        from urllib.parse import urlsplit
        if urlsplit(origin).netloc!=request.host:return web.json_response({'error':'Origin mismatch'},status=403)
    body=await request.json();profile=body.get('profile')
    if profile not in ('film','design','graphics','full'):return web.json_response({'error':'Invalid profile'},status=400)
    if process is not None and process.poll() is None:return web.json_response({'error':'A download is already running'},status=409)
    cfgpath=HERE/'config.json'
    if not cfgpath.exists():return web.json_response({'error':'Run the Jupyter setup notebook first.'},status=409)
    cfg=json.loads(cfgpath.read_text())
    if log_handle:log_handle.close()
    log_handle=(HERE/'model_download.log').open('w')
    process=subprocess.Popen([cfg['python']['vision'],'-u',str(HERE/'installer/model_manager.py'),'--config',str(cfgpath),'--profile',profile],stdout=log_handle,stderr=subprocess.STDOUT,start_new_session=True)
    return web.json_response(state())

@PromptServer.instance.routes.post('/afterglow-studio/models/cancel')
async def cancel(request):
    origin=request.headers.get('Origin')
    if origin:
        from urllib.parse import urlsplit
        if urlsplit(origin).netloc!=request.host:return web.json_response({'error':'Origin mismatch'},status=403)
    if process is not None and process.poll() is None:os.killpg(process.pid,signal.SIGTERM)
    return web.json_response({'message':'Download stopped; completed files and partial downloads are retained.'})
