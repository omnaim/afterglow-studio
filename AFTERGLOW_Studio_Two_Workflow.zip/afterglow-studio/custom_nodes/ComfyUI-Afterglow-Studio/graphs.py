"""Native, source-verified ComfyUI API graphs. No hosted/partner nodes."""
import math

class Graph(dict):
    def node(self,kind,**values):
        key=str(len(self)+1);self[key]={'class_type':kind,'inputs':values};return [key,0]
    def output(self,link,index):return [link[0],index]

def keyframe(prompt,references,destination,seed,width,height):
    g=Graph()
    m=g.node('UNETLoader',unet_name='qwen_image_2.1_bf16.safetensors',weight_dtype='default')
    clip=g.node('CLIPLoader',clip_name='qwen3vl_8b_bf16.safetensors',type='qwen_image',device='default')
    vae=g.node('VAELoader',vae_name='qwen_image_2.1_vae_bf16.safetensors')
    images={f'images.image_{i}':g.node('LoadImage',image=p) for i,p in enumerate(references,1)}
    # The first image is already reframed to the target canvas, preserving aspect.
    cond=g.node('TextEncodeQwenImage21',clip=clip,vae=vae,prompt=prompt,negative_prompt='',resolution=0,**images)
    lat=g.node('KSampler',model=m,seed=seed,steps=40,cfg=1.0,sampler_name='euler',scheduler='simple',positive=cond,negative=g.output(cond,1),latent_image=g.output(cond,2),denoise=1.0)
    im=g.node('VAEDecode',samples=lat,vae=vae)
    g.node('StudioWriteImage',images=im,relative_path=destination)
    return g

def h3(prompt,references,destination,seed,width,height,duration,audio=None,first_frame=None):
    g=Graph()
    model=g.node('UNETLoader',unet_name='minimax_h3_ref2va_bf16.safetensors',weight_dtype='default')
    clip=g.node('CLIPLoader',clip_name='qwen3vl_32b_minimax_h3_bf16.safetensors',type='minimax',device='default')
    vae=g.node('VAELoader',vae_name='minimax_h3_video_vae_fp16.safetensors')
    avae=g.node('VAELoader',vae_name='minimax_h3_audio_vae_fp32.safetensors')
    refs={f'ref_images.ref_image_{i}':g.node('LoadImage',image=p) for i,p in enumerate(references)}
    frames=math.ceil(duration*24)
    while frames%17!=5:frames+=1
    cond=g.node('MiniMaxH3ReferenceToVideo',clip=clip,vae=vae,audio_vae=avae,prompt=prompt,width=width,height=height,length=frames,ref_image_size='max',**refs)
    positive=cond
    if first_frame:
        im=g.node('LoadImage',image=first_frame)
        positive=g.node('MiniMaxH3AddGuide',positive=positive,latent=g.output(cond,1),vae=vae,image=im,frame_idx=0)
    if audio:
        wav=g.node('LoadAudio',audio=audio)
        # Anchors the same speech waveform used in the final mix. H3's synthesized
        # soundtrack is discarded; it cannot introduce music into that mix.
        positive=g.node('MiniMaxH3AddGuide',positive=positive,latent=g.output(cond,1),audio_vae=avae,audio=wav,frame_idx=0)
    guide=g.node('BasicGuider',model=model,conditioning=positive)
    noise=g.node('RandomNoise',noise_seed=seed)
    sampler=g.node('KSamplerSelect',sampler_name='res_multistep')
    sigmas=g.node('BasicScheduler',model=model,scheduler='simple',steps=20,denoise=1.0)
    lat=g.node('SamplerCustomAdvanced',noise=noise,guider=guide,sampler=sampler,sigmas=sigmas,latent_image=g.output(cond,1))
    frames_out=g.node('VAEDecode',samples=lat,vae=vae)
    g.node('StudioWriteFrames',images=frames_out,relative_path=destination,duration=duration,fps=24)
    return g
