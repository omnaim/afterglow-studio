"""Production coordinator for film/series and motion/product workspaces."""
import argparse,fcntl,hashlib,json,os,shutil,signal,sys
from pathlib import Path
from common import atomic_json,ingest,sha256
from contracts import FORMATS,schedule,slug,validate_shots
from runtime import task,comfy_worker,submit,progress
from graphs import keyframe,h3
from finish import crop,framed,contact_sheet,render_design,still_background,design_sfx,mix_audio,export_edit,master,checked_video

HERE=Path(__file__).resolve().parent

def copied(src,dst):
    dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
    temporary=dst.with_suffix(dst.suffix+'.tmp');shutil.copyfile(src,temporary);temporary.replace(dst);return str(dst)

def select(candidates,scores,threshold):
    passing=[c for c in candidates if not scores[c['id']]['hard_reject'] and scores[c['id']]['score']>=threshold]
    return max(passing,key=lambda c:scores[c['id']]['score']) if passing else None

def production(config,options):
    if config.get('version')!=2:raise ValueError('Run the Studio setup script to create config version 2.')
    inp=Path(config['input_dir']).resolve();out=Path(config['output_dir']).resolve()
    source=Path(options['source']).resolve()
    if not source.is_relative_to(inp) or not source.is_file():raise ValueError('Upload source into this ComfyUI input directory.')
    project=slug(options['project']);mode=options['mode'];episode=int(options['episode'])
    library=out/'studio_projects'/project;library.mkdir(parents=True,exist_ok=True)
    # Serializes episodes/revisions of a project; releases automatically on failure/cancel.
    with (library/'project.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('This project already has an active render. Wait or use a different project name.')
        if (library/'project.json').exists():
            metadata=json.loads((library/'project.json').read_text())
            if metadata['mode']!=mode:raise ValueError('Film and design require separate project names.')
        else:atomic_json(library/'project.json',{'mode':mode,'project':project,'schema':2})
        return produce_locked(config,options,source,inp,out,library,episode)

def produce_locked(config,o,source,inp,out,library,episode):
    source_hash=sha256(source);seed=o['seed'];mode=o['mode'];durations=schedule(o['duration'])
    width,height,dw,dh=FORMATS[o['format']]
    # Bible and history are intentionally excluded from the completed-job key:
    # committing the current episode must not invalidate that exact render on resume.
    signature={'source':source_hash,'options':{k:v for k,v in o.items() if k!='source'},'config':config,'code':{p.name:sha256(p) for p in HERE.glob('*.py')}}
    digest=hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest()[:16]
    relative=f'studio_projects/{library.name}/episode_{episode:03d}/{digest}'
    job=out/relative;job.mkdir(parents=True,exist_ok=True);assets=inp/relative;assets.mkdir(parents=True,exist_ok=True)
    complete=job/'completed.json'
    if complete.exists():
        result=json.loads(complete.read_text())
        if Path(result['master']).exists():progress('complete','Returning this completed production');return result
    atomic_json(job/'job.json',signature)
    intakepath=job/'intake/intake.json'
    intake=json.loads(intakepath.read_text()) if intakepath.exists() else ingest(source,job/'intake')
    progress('intake',f'Extracted {len(intake["assets"])} source assets')
    biblepath=library/'bible.json'
    if biblepath.exists():bible=json.loads(biblepath.read_text())
    else:
        bible=task(config,'vision_worker.py','vision',{'mode':'bible','intake':intake,'production_mode':mode,'brief':o['brief']},job,'bible')
        # Immutable reference pixels live under input so native LoadImage can read them.
        stable=inp/'studio_cast'/library.name;stable.mkdir(parents=True,exist_ok=True)
        anchor_paths={c['id']:crop(c['anchor'],intake,stable/f'{c["id"]}.png') for c in bible['characters']}
        for name in ['product','logo']:
            if bible['brand'].get(name):anchor_paths[name]=crop(bible['brand'][name],intake,stable/f'{name}_source.png')
        atomic_json(library/'anchors.json',anchor_paths);atomic_json(biblepath,bible)
        copied(source,library/('original_source'+source.suffix.lower()))
    anchors=json.loads((library/'anchors.json').read_text())
    if any(not Path(p).is_file() for p in anchors.values()):raise RuntimeError('A persistent cast/product anchor is missing; restore studio_cast assets.')
    visual_mode=o.get('visual_mode','Automatic')
    if visual_mode=='Automatic':visual_mode='Product artwork' if 'product' in anchors else 'Scene animation'
    protected=mode=='design' and visual_mode=='Product artwork'
    if mode=='design' and visual_mode.startswith('Product') and 'product' not in anchors:raise ValueError('The source did not yield a product reference. Use Scene animation or provide a clear product image.')
    # Freeze prior story context per render; future episodes cannot alter a resumed plan.
    contextpath=job/'context.json'
    if not contextpath.exists():
        historypath=library/'history.json';history=json.loads(historypath.read_text()) if historypath.exists() else []
        atomic_json(contextpath,[h for h in history if h['episode']<episode][-20:])
    history=json.loads(contextpath.read_text())
    plan=task(config,'vision_worker.py','vision',{'mode':'plan','intake':intake,'production_mode':mode,'visual_mode':visual_mode,'brief':o['brief'],'bible':bible,'durations':durations,'history':history},job,'plan')
    validate_shots(plan['shots'],intake,bible,durations,1,mode)
    shots=plan['shots'];by_id={s['index']:s for s in shots}
    # Preserve sparse factual headlines and immutable brand art in an editable plan.
    progress('plan',f'Planned {len(shots)} shots / {sum(durations)} seconds')
    references={}
    for shot in shots:
        i=shot['index'];raw=assets/f'scene_{i:04d}.png';canvas=assets/f'canvas_{i:04d}.png'
        if not raw.exists():crop(shot['scene'],intake,raw)
        if not canvas.exists():framed(raw,canvas,width,height)
        refs=[str(canvas.relative_to(inp))]
        refs += [str(Path(anchors[c]).relative_to(inp)) for c in shot['subjects']]
        if mode=='design' and visual_mode=='Product animation':refs.append(str(Path(anchors['product']).relative_to(inp)))
        references[i]=refs
    speech={}
    if any(s.get('speech') for s in shots):
        voices={c['id']:c['voice_description'] for c in bible['characters']}
        voices['narrator']='An adult voice with a warm low register, clear articulation and restrained natural expression.'
        # Every episode reuses exactly the same synthetic casting audio files.
        casts=task(config,'speech_worker.py','voice_design',{'mode':'cast','voices':voices,'seed':seed,'directory':str(library/'voices')},library,'casting')
        speech=task(config,'speech_worker.py','arabic',{'mode':'arabic','plan':plan,'casts':casts,'seed':seed,'directory':str(assets/'speech')},job,'speech')
    strict=o['quality']=='Production';copies=3 if strict else 1;threshold=7.5 if strict else 0
    stages={};all_scores={};selection={}
    for kind in ['keyframe','video']:
        if kind=='video' and mode=='design' and o['background']=='Graphic motion':continue
        chosen_path=job/f'{kind}_selected.json'
        if chosen_path.exists():
            selected=json.loads(chosen_path.read_text())
            if all(Path(c['path']).exists() for c in selected.values()):selection[kind]=selected;continue
        selected={};candidates={str(s['index']):[] for s in shots};scores={}
        for round_ in range(2 if strict else 1):
            pending=[s for s in shots if str(s['index']) not in selected]
            if not pending:break
            items=[]
            progress(kind,f'{kind.title()} candidates, round {round_+1}; {len(pending)} shots')
            with comfy_worker(config,job) as (base,info):
                for shot in pending:
                    i=shot['index'];sid=str(i)
                    previous_issues=[scores[c['id']]['issues'] for c in candidates[sid] if c['id'] in scores]
                    correction=' Fix prior take issues: '+json.dumps(previous_issues) if previous_issues else ''
                    for take in range(copies):
                        tid=round_*copies+take;ident=f'{kind}_{i:04d}_{tid}';sample_seed=(seed+i*101+tid*10007+(900000 if kind=='video' else 0))%(2**32)
                        if kind=='keyframe':
                            rel=f'{relative}/takes/{ident}.png';path=inp/rel;path.parent.mkdir(parents=True,exist_ok=True)
                            if mode=='film':
                                descriptions=' '.join(f'<image{j+2}> is {cid}: '+next(c['description']+'; wardrobe '+c['wardrobe'] for c in bible['characters'] if c['id']==cid) for j,cid in enumerate(shot['subjects']))
                                brief=f'Create one clean cinematic frame. <image1> is the scene composition reference. {descriptions}. Only these characters: {shot["subjects"]}. Maintain every supplied identity and wardrobe. '+shot['image_prompt']
                            elif protected:brief='Create only an empty premium visual stage/background. No product, people, logos, symbols or text. '+shot['image_prompt']
                            else:brief=f'Create one clean {visual_mode} keyframe faithful to the supplied reference images. Preserve all subject/product identity, material, shape, proportions, colors and existing markings. Do not add text or logos. '+shot['image_prompt']
                            prompt=brief+' Style: '+bible['style']+' Preserve natural or intentional stylized material texture. Avoid beauty retouching, plastic surfaces and excessive sharpening.'+correction
                            graph=keyframe(prompt,references[i],rel,sample_seed,width,height)
                        else:
                            rel=f'{relative}/takes/{ident}.mkv';path=out/rel;path.parent.mkdir(parents=True,exist_ok=True)
                            k=selection['keyframe'][sid]['path'];refs=[str(Path(k).relative_to(inp))]
                            refs += [str(Path(anchors[c]).relative_to(inp)) for c in shot['subjects']]
                            if mode=='design' and visual_mode=='Product animation':refs.append(str(Path(anchors['product']).relative_to(inp)))
                            identities=' '.join(f'<Picture {j+2}> is the immutable identity of {cid}.' for j,cid in enumerate(shot['subjects']))
                            prev=selection['keyframe'].get(str(i-1))
                            if prev and mode=='film':
                                refs.append(str(Path(prev['path']).relative_to(inp)));identities+=f' <Picture {len(refs)}> is the previous shot, for light and visual continuity only.'
                            brief=f'One continuous {shot["duration"]}-second shot. <Picture 1> defines the composition, materials and lighting. {identities} {bible["style"]}. {shot["motion_prompt"]}. Preserve identities, clothes, object geometry, existing labels/markings and screen direction. No internal cut, added captions, added logos, watermark or background music.'
                            audio=None
                            if shot.get('speech') and shot['speech']['mode']=='dialogue':
                                audio=str(Path(speech[sid]).relative_to(inp));brief+=' The single visible actor speaks Arabic in exact sync with the supplied anchored audio: '+shot['speech']['text_ar']
                            else:brief+=' No visible talking; mouths remain naturally relaxed and closed.'
                            if protected:brief+=' Empty background only. The product and typography are added later; do not generate either.'
                            graph=h3(brief+correction,refs,rel,sample_seed,width,height,shot['duration'],audio=audio,first_frame=refs[0])
                        if not path.exists():submit(base,info,graph,job,ident)
                        if not path.exists():raise RuntimeError(f'{ident} has no saved result.')
                        if kind=='video':checked_video(path,shot['duration'],width,height)
                        sheet=str(path)
                        if kind=='video':
                            sheet=str(job/f'{ident}.jpg')
                            if not Path(sheet).exists():contact_sheet(path,sheet,shot['duration'])
                        candidate={'id':ident,'path':str(path),'seed':sample_seed};candidates[sid].append(candidate)
                        identity_images=[anchors[c] for c in shot['subjects']]
                        if mode=='design' and visual_mode=='Product animation':identity_images.append(anchors['product'])
                        if mode=='design' and visual_mode=='Scene animation':identity_images.append(str(inp/references[i][0]))
                        if kind=='video':identity_images.insert(0,selection['keyframe'][sid]['path'])
                        items.append({'id':ident,'empty_background':protected,'brief':f'Mode={mode}; {brief}; continuity: {shot["continuity"]}','images':identity_images+[sheet]})
            if not items:break
            assessments=task(config,'vision_worker.py','vision',{'mode':'critic','items':items},job,f'{kind}_critic_round_{round_}')
            scores.update(assessments)
            for s in pending:
                sid=str(s['index']);best=select(candidates[sid],scores,threshold)
                if not strict and best is None:best=max(candidates[sid],key=lambda c:scores[c['id']]['score'])
                if best:selected[sid]=best
            atomic_json(job/f'{kind}_candidate_report.json',{'candidates':candidates,'scores':scores,'selected':selected})
        missing=[s['index'] for s in shots if str(s['index']) not in selected]
        if missing:
            atomic_json(job/'quality_hold.json',{'stage':kind,'shots':missing,'reason':'No candidate passed the configured 7.5/10 visual estimate and hard-reject gate.','action':'Inspect candidate reports. Change the creative brief or seed to make a new render; completed candidates are retained.'})
            raise RuntimeError(f'Production quality gate held shots {missing}. See {job}/quality_hold.json. No production master was marked complete.')
        atomic_json(chosen_path,selected);selection[kind]=selected;all_scores[kind]=scores
    clips=[];cutouts={}
    if mode=='design':
        art={k:v for k,v in anchors.items() if k in ('product','logo')}
        if art:cutouts=task(config,'segment_worker.py','segment',{'assets':art,'directory':str(library/'brand_layers')},library,'brand_cutouts')
        if not protected:cutouts={k:v for k,v in cutouts.items() if k!='product'}
    final_clips=job/'clips';final_clips.mkdir(exist_ok=True);overlaydir=job/'alpha_overlays';overlaydir.mkdir(exist_ok=True)
    for shot in shots:
        sid=str(shot['index']);path=final_clips/f'S{shot["index"]:06d}.mkv'
        if not path.exists():
            if mode=='film':copied(selection['video'][sid]['path'],path)
            else:
                if 'video' in selection:bg=selection['video'][sid]['path']
                else:
                    bg=job/f'background_{shot["index"]:04d}.mkv'
                    if not bg.exists():still_background(selection['keyframe'][sid]['path'],bg,shot['duration'],width,height)
                overlay=overlaydir/f'S{shot["index"]:06d}.mov' if o['edit_pack'] else None
                progress('design',f'Compositing exact artwork and Arabic typography, shot {shot["index"]}/{len(shots)}')
                render_design(shot,bible,cutouts,bg,path,dw,dh,overlay)
        clips.append(str(path))
    if mode=='design':
        items=[]
        for shot,path in zip(shots,clips):
            ident=f'delivery_{shot["index"]:04d}';sheet=job/(ident+'.jpg')
            if not sheet.exists():contact_sheet(path,sheet,shot['duration'])
            items.append({'id':ident,'delivery':True,'brief':'Final product/motion composite. Preserve original packaging, labels, logo, colors and proportions. Correct joined Arabic text, readable safe margins, no unintended clipping or duplicated product. Expected headline: '+shot['layout']['headline_ar'],'images':[p for k,p in anchors.items() if k in ('product','logo')]+[str(sheet)]})
        final_scores=task(config,'vision_worker.py','vision',{'mode':'critic','items':items},job,'delivery_critic')
        rejected=[k for k,v in final_scores.items() if v['hard_reject'] or v['score']<threshold]
        if strict and rejected:
            atomic_json(job/'quality_hold.json',{'stage':'design_delivery','shots':rejected,'scores':final_scores,'action':'Inspect the source crop, segmentation mask and layout. Choose a cleaner source or revise the brief before delivery.'})
            raise RuntimeError('Final product/typography review held the production master; inspect quality_hold.json and brand_layers.')
    if mode=='film':
        proxies=[]
        from common import ffmpeg
        for shot,path in zip(shots,clips):
            proxy=job/f'foley_proxy_{shot["index"]:04d}.mp4'
            if not proxy.exists():ffmpeg(['-y','-i',path,'-an','-c:v','libx264','-crf','19','-pix_fmt','yuv420p',str(proxy)])
            proxies.append(str(proxy))
        foley=task(config,'foley_worker.py','foley',{'plan':plan,'videos':proxies,'seed':seed,'directory':str(job/'foley')},job,'foley')
    else:foley=design_sfx(shots,job/'sound_design',seed)
    audio=job/'Arabic_and_Foley.wav';subs=mix_audio(plan,foley,speech,audio)
    export_edit(plan,clips,subs,job)
    progress('finish','Rendering the delivery master and editorial files')
    master_path=master(clips,audio,job/('MASTER.mp4' if strict else 'PREVIEW.mp4'),dw,dh,sum(durations),mezzanine=o['edit_pack'])
    report={'master':master_path,'mode':mode,'project':library.name,'episode':episode,'duration':sum(durations),'fps':24,'width':dw,'height':dh,'speech_language':'ar','music_model':False,'quality':o['quality'],'quality_gate':'visual estimate passed' if strict else 'preview; quality gates bypassed','edit_pack':o['edit_pack'],'project_directory':str(library),'job_directory':str(job),'continuity':'persistent original anchors and synthetic cast voices','models':config.get('model_revisions',[]),'limitations':['Visual scoring does not certify identity or Arabic lip sync.','Product foreground animation preserves the supplied view; unseen sides require more reference images or a 3D asset.','1080 delivery is resized from H3 base footage, not H3 hosted 2K regeneration.']}
    # Only completed Production output advances the story state. Preview is disposable.
    if strict:
        histpath=library/'history.json';hist=json.loads(histpath.read_text()) if histpath.exists() else []
        prior=[h for h in hist if h['episode']==episode]
        if prior:atomic_json(job/'prior_episode_versions.json',prior)
        hist=[h for h in hist if h['episode']!=episode]
        hist.append({'episode':episode,'source_sha256':source_hash,'master':master_path,'outline':plan['outline'],'ending':shots[-1]['continuity']});hist.sort(key=lambda h:h['episode']);atomic_json(histpath,hist)
    atomic_json(complete,report);progress('complete',f'Finished {sum(durations)} seconds');return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--options',type=Path,required=True);a=p.parse_args()
    def terminate(signum,frame):raise KeyboardInterrupt('Production cancelled')
    signal.signal(signal.SIGTERM,terminate)
    result=production(json.loads(a.config.read_text()),json.loads(a.options.read_text()));print('@@RESULT:'+json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
