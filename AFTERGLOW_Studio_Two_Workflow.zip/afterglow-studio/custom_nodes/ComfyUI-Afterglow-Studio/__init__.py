"""ComfyUI all-in-one film/series and motion/product production nodes."""
import hashlib,json,os,selectors,signal,subprocess,uuid
from pathlib import Path
import folder_paths
from aiohttp import web
from server import PromptServer
from .media_nodes import MAPPINGS
from . import download_routes
from .contracts import FORMATS,slug

HERE=Path(__file__).resolve().parent;WEB_DIRECTORY='./web'
ALLOWED={'.pdf','.png','.jpg','.jpeg','.webp'}

def resolve_source(name):
    root=Path(folder_paths.get_input_directory()).resolve();p=(root/name).resolve()
    if not p.is_relative_to(root) or not p.is_file() or p.suffix.lower() not in ALLOWED:raise ValueError('Choose an uploaded PDF or image.')
    return p

class StudioSource:
    @classmethod
    def INPUT_TYPES(cls):
        root=Path(folder_paths.get_input_directory());upload=root/'studio_uploads'
        files=sorted(str(p.relative_to(root)) for p in upload.rglob('*') if p.is_file() and p.suffix.lower() in ALLOWED) if upload.exists() else []
        return {'required':{'source_file':(files or ['Upload a PDF or image'],)}}
    RETURN_TYPES=('STRING',);RETURN_NAMES=('source_path',);FUNCTION='load';CATEGORY='Afterglow Studio'
    @classmethod
    def VALIDATE_INPUTS(cls,source_file):
        try:resolve_source(source_file);return True
        except ValueError as e:return str(e)
    @classmethod
    def IS_CHANGED(cls,source_file):return hashlib.sha256(resolve_source(source_file).read_bytes()).hexdigest()
    def load(self,source_file):return (str(resolve_source(source_file)),)

class StudioProduction:
    MODE='film'
    @classmethod
    def INPUT_TYPES(cls):
        required={'source_path':('STRING',{'forceInput':True}),'project':('STRING',{'default':'my_series' if cls.MODE=='film' else 'my_brand'}),'episode':('INT',{'default':1,'min':1,'max':9999}),'duration':('INT',{'default':90,'min':15,'max':3600,'step':1}),'format':(list(FORMATS),{'default':'Vertical 9:16'}),'quality':(['Production','Preview'],{'default':'Production'}),'brief':('STRING',{'default':'Adapt the uploaded reference faithfully. Natural Arabic speech. Preserve the visual style. No music.','multiline':True}),'edit_pack':('BOOLEAN',{'default':True}),'seed':('INT',{'default':9401,'min':0,'max':2**32-1,'control_after_generate':True})}
        if cls.MODE=='design':
            required['background']=(['Graphic motion','H3 animated background'],{'default':'H3 animated background'})
            required['visual_mode']=(['Automatic','Product artwork','Product animation','Scene animation'],{'default':'Automatic'})
        return {'required':required,'hidden':{'unique_id':'UNIQUE_ID'}}
    RETURN_TYPES=('VIDEO','STRING');RETURN_NAMES=('finished_video','production_report');FUNCTION='produce';CATEGORY='Afterglow Studio';OUTPUT_NODE=True
    @classmethod
    def IS_CHANGED(cls,**kwargs):return float('nan')
    def produce(self,source_path,project,episode,duration,format,quality,brief,edit_pack,seed,background='H3 animated background',visual_mode='Automatic',unique_id=None):
        slug(project);cfgpath=HERE/'config.json'
        if not cfgpath.exists():raise RuntimeError('Run tools/setup_local.py from the Studio package, then restart ComfyUI.')
        cfg=json.loads(cfgpath.read_text())
        profile='film' if self.MODE=='film' else ('graphics' if background=='Graphic motion' else 'design')
        if 'ready_profiles' in cfg and profile not in cfg['ready_profiles']:
            raise RuntimeError('Use Download / resume models on this node and wait until '+profile+' is ready.')
        root=Path(folder_paths.get_input_directory()).resolve();source=Path(source_path).resolve()
        if not source.is_relative_to(root) or not source.is_file():raise ValueError('Source must be inside this ComfyUI input folder.')
        if Path(cfg['input_dir']).resolve()!=root or Path(cfg['output_dir']).resolve()!=Path(folder_paths.get_output_directory()).resolve():raise ValueError('Setup paths differ from the running ComfyUI paths.')
        options={'source':str(source),'project':project,'episode':episode,'duration':duration,'format':format,'quality':quality,'brief':brief,'edit_pack':edit_pack,'seed':seed,'mode':self.MODE,'background':background,'visual_mode':visual_mode}
        requests=Path(cfg['output_dir'])/'studio_requests';requests.mkdir(exist_ok=True);req=requests/(uuid.uuid4().hex+'.json');req.write_text(json.dumps(options,ensure_ascii=False))
        import comfy.model_management
        comfy.model_management.unload_all_models();comfy.model_management.soft_empty_cache(force=True)
        process=subprocess.Popen([cfg['python']['vision'],str(HERE/'engine.py'),'--config',str(cfgpath),'--options',str(req)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
        selector=selectors.DefaultSelector();selector.register(process.stdout,selectors.EVENT_READ);report=None;tail=[]
        def consume(line):
            nonlocal report,tail
            tail=(tail+[line])[-40:]
            if line.startswith('@@AFTERGLOW:'):
                data=json.loads(line.split(':',1)[1]);data['node_id']=str(unique_id);PromptServer.instance.send_sync('afterglow.studio.progress',data);print('[Studio] '+data['text'],flush=True)
            elif line.startswith('@@RESULT:'):report=json.loads(line.split(':',1)[1])
        try:
            while process.poll() is None:
                comfy.model_management.throw_exception_if_processing_interrupted()
                for key,_ in selector.select(timeout=1):consume(key.fileobj.readline())
            for line in process.stdout:consume(line)
            if process.returncode or report is None:raise RuntimeError('Studio render stopped. Completed stages are retained.\n'+''.join(tail)[-6500:])
        finally:
            selector.close()
            if process.poll() is None:
                os.killpg(process.pid,signal.SIGTERM)
                try:process.wait(timeout=40)
                except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
            req.unlink(missing_ok=True)
        from comfy_api.latest import InputImpl
        path=Path(report['master']).resolve();output=Path(folder_paths.get_output_directory()).resolve()
        if not path.is_relative_to(output) or not path.is_file():raise ValueError('Invalid master output.')
        rel=path.relative_to(output)
        return {'ui':{'text':[str(path),f'{duration}s • Arabic • {quality}'],'studio_video':[{'filename':rel.name,'subfolder':str(rel.parent),'type':'output'}]},'result':(InputImpl.VideoFromFile(str(path)),json.dumps(report,ensure_ascii=False,indent=2))}

class StudioFilm(StudioProduction):MODE='film'
class StudioDesign(StudioProduction):MODE='design'

@PromptServer.instance.routes.post('/afterglow-studio/upload')
async def upload(request):
    reader=await request.multipart();part=await reader.next()
    if not part or part.name!='file' or not part.filename:return web.json_response({'error':'Expected one file'},status=400)
    suffix=Path(part.filename).suffix.lower()
    if suffix not in ALLOWED:return web.json_response({'error':'Use PDF, PNG, JPEG or WebP'},status=400)
    root=Path(folder_paths.get_input_directory())/'studio_uploads';root.mkdir(exist_ok=True);path=root/(uuid.uuid4().hex+suffix)
    try:
        size=0
        with path.open('wb') as f:
            while chunk:=await part.read_chunk(size=1024*1024):
                size+=len(chunk)
                if size>200*1024*1024:raise ValueError('Maximum file size: 200 MiB')
                f.write(chunk)
        if suffix=='.pdf':
            import fitz
            with fitz.open(path) as doc:
                if doc.needs_pass or not 1<=len(doc)<=16:raise ValueError('Use an unlocked PDF with 1–16 pages.')
        else:
            from PIL import Image
            with Image.open(path) as im:im.verify()
    except Exception as e:
        path.unlink(missing_ok=True);return web.json_response({'error':str(e)},status=400)
    return web.json_response({'name':'studio_uploads/'+path.name,'original_name':Path(part.filename).name})

NODE_CLASS_MAPPINGS={**MAPPINGS,'StudioSource':StudioSource,'StudioFilm':StudioFilm,'StudioDesign':StudioDesign}
NODE_DISPLAY_NAME_MAPPINGS={'StudioSource':'Studio · Upload PDF / Image','StudioFilm':'Studio · Series & Movie Production','StudioDesign':'Studio · Motion & Product Design'}
