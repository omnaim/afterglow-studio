"""One-file local production engine. GPU workloads run sequentially in subprocesses.

The isolated ComfyUI worker prevents a director node from deadlocking its own queue.
The worker uses loopback only; all inference model reads are offline/local.
"""
import argparse
import contextlib
import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps
from common import atomic_json, ffmpeg, ingest, sha256
from comfy_client import preflight, queue_and_wait, request

HERE=Path(__file__).resolve().parent


def progress(stage,text):
    print('@@AFTERGLOW:'+json.dumps({'stage':stage,'text':text},ensure_ascii=False),flush=True)


def local_env(config):
    env=os.environ.copy()
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',
               HF_HUB_CACHE=config['hub_cache'],TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1')
    return env


def task(config,script,python_role,data,jobdir,name):
    output=jobdir/f'{name}.json'
    if output.is_file():return json.loads(output.read_text())
    req=jobdir/f'{name}_request.json';atomic_json(req,{**data,'config':config,'output':str(output)})
    progress(name,f'Running local {name} model stage')
    with (jobdir/f'{name}.log').open('wb') as log:
        result=subprocess.run([config['python'][python_role],str(HERE/script),'--request',str(req)],
                              env=local_env(config),stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        tail=(jobdir/f'{name}.log').read_text(errors='replace')[-3500:]
        raise RuntimeError(f'{name} failed; see {jobdir/name}.log\n{tail}')
    if not output.is_file():raise RuntimeError(f'{name} returned without a result.')
    return json.loads(output.read_text())


@contextlib.contextmanager
def comfy_worker(config,jobdir):
    with socket.socket() as s:
        s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    base=f'http://127.0.0.1:{port}';log=(jobdir/'comfy_worker.log').open('ab')
    command=[config['python']['comfy'],str(Path(config['comfy_root'])/'main.py'),
             '--listen','127.0.0.1','--port',str(port),'--disable-auto-launch','--offline','--cache-none',
             '--input-directory',config['input_dir'],'--output-directory',config['output_dir']]
    command+=config.get('worker_args',[])
    process=subprocess.Popen(command,cwd=config['comfy_root'],env=local_env(config),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        start=time.monotonic();info=None
        while time.monotonic()-start<300:
            if process.poll() is not None:raise RuntimeError('Isolated ComfyUI worker stopped during startup; inspect comfy_worker.log.')
            try:
                info=request(base,'/object_info');break
            except (OSError,RuntimeError):time.sleep(2)
        if info is None:raise RuntimeError('Isolated ComfyUI worker did not become ready within 300 seconds.')
        yield base,info
    finally:
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);process.wait()
        log.close()


def submit(base,info,prompt,jobdir,label):
    # Actual live node schema/model checks before each generation.
    preflight(prompt,info)
    result=queue_and_wait(base,prompt,'afterglow-studio',21600)
    atomic_json(jobdir/f'{label}_execution.json',{'prompt':prompt,'history':result})
    return result


