"""Generate synthetic casting references, then Arabic speech with ASR retries.

Run casting in the Qwen VoiceDesign environment, Arabic TTS in its own environment.
No voice is inferred or cloned from the person in the uploaded visual file.
"""
import argparse
import json
import math
from pathlib import Path

from common import atomic_json, character_error_rate, ffmpeg


def main():
    p=argparse.ArgumentParser();p.add_argument('--request',type=Path,required=True)
    args=p.parse_args();job=json.loads(args.request.read_text());config=job['config']
    import numpy as np
    import soundfile as sf
    import torch
    if job['mode']=='cast':
        from qwen_tts import Qwen3TTSModel
        model=Qwen3TTSModel.from_pretrained(config['models']['voice_design'],device_map='cuda:0',dtype=torch.bfloat16,attn_implementation='sdpa')
        out=Path(job['directory']);out.mkdir(parents=True,exist_ok=True)
        voices=job['voices']
        result={}
        # English is used only to create synthetic tone/identity references because
        # Qwen VoiceDesign does not support Arabic. It never enters the final mix.
        sample='I remember the quiet streets after the rain. Some memories stay with us long after the lights go out. Tonight I am finally ready to let them rest.'
        for i,(speaker,description) in enumerate(voices.items()):
            torch.manual_seed(job['seed']+i)
            wavs,sr=model.generate_voice_design(text=sample,language='English',instruct=description+' Natural human delivery, quiet intimate speech, restrained emotion, no theatrical performance.')
            path=out/f'{speaker}_synthetic_cast.wav';sf.write(path,wavs[0],sr)
            result[speaker]=str(path.resolve())
        atomic_json(job['output'],result);return
    if job['mode']=='arabic':
        import librosa
        from chatterbox.mtl_tts import ChatterboxMultilingualTTS
        from transformers import WhisperProcessor, WhisperForConditionalGeneration
        tts=ChatterboxMultilingualTTS.from_local(config['models']['arabic_tts'],device='cuda',t3_model='v3')
        processor=WhisperProcessor.from_pretrained(config['models']['asr'],local_files_only=True)
        asr=WhisperForConditionalGeneration.from_pretrained(config['models']['asr'],local_files_only=True,torch_dtype=torch.float16).to('cuda')
        def transcribe(path):
            signal=librosa.load(path,sr=16000,mono=True)[0]
            features=processor(signal,sampling_rate=16000,return_tensors='pt').input_features.to('cuda',dtype=torch.float16)
            with torch.inference_mode():ids=asr.generate(features,language='ar',task='transcribe',max_new_tokens=256)
            return processor.batch_decode(ids,skip_special_tokens=True)[0]
        output=Path(job['directory']);output.mkdir(parents=True,exist_ok=True);results={};checks={}
        for shot in job['plan']['shots']:
            speech=shot.get('speech')
            if not speech:continue
            index=shot['index'];duration_limit=shot['duration'];budget=duration_limit-0.6;ref=job['casts'][speech['speaker']];candidates=[]
            for take in range(3):
                torch.manual_seed(job['seed']+index*100+take)
                wav=tts.generate(speech['text_ar'],language_id='ar',audio_prompt_path=ref,exaggeration=0.35,cfg_weight=0.35,temperature=0.7+take*0.05)
                path=output/f'shot_{index:02d}_speech_take_{take}.wav'
                sf.write(path,wav.squeeze(0).detach().cpu().numpy(),tts.sr)
                transcript=transcribe(path);cer=character_error_rate(speech['text_ar'],transcript)
                duration=sf.info(path).duration
                candidates.append({'path':str(path),'cer':cer,'transcript':transcript,'duration':duration})
                if cer<=0.20 and duration<=budget:break
            acceptable=[c for c in candidates if c['cer']<=0.25 and 0.15<c['duration']<=budget*1.08]
            if not acceptable:
                atomic_json(output/f'shot_{index:02d}_speech_failures.json',candidates)
                raise RuntimeError(f'Arabic speech for shot {index} failed ASR or timing after 3 tries. No English fallback or truncated dialogue is used.')
            best=min(acceptable,key=lambda x:x['cer']);speed=max(1.0,best['duration']/budget)
            if speed>1.08:raise RuntimeError('Arabic dialogue exceeds natural timing budget.')
            final=output/f'shot_{index:02d}_speech.wav'
            # Exactly the same timed waveform guides H3 and enters the final mix.
            filt=f'atempo={speed:.6f},adelay=300|300,apad,atrim=duration={duration_limit},aresample=48000'
            ffmpeg(['-y','-i',best['path'],'-af',filt,'-ac','2',str(final)])
            final_transcript=transcribe(final);final_cer=character_error_rate(speech['text_ar'],final_transcript)
            if final_cer>0.25:raise RuntimeError(f'Final Arabic waveform failed transcript consistency for shot {index}.')
            results[str(index)]=str(final.resolve());checks[str(index)]={'text_ar':speech['text_ar'],'transcript_ar':final_transcript,'cer':final_cer,'tempo_factor':speed,'attempts':candidates}
        atomic_json(job['output'],results);atomic_json(output/'arabic_asr_checks.json',checks);return
    raise ValueError('Unknown speech task')


if __name__=='__main__':main()
