import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
let extension;const events={};let response={ok:true,data:{name:'studio_uploads/file.pdf',original_name:'story.pdf'}};let picker;
const app={registerExtension:x=>extension=x,graph:{setDirtyCanvas(){},getNodeById:id=>id===2?director:null},extensionManager:{toast:{add(){}}}};
const api={fetchApi:async()=>({ok:response.ok,json:async()=>response.data}),apiURL:path=>path,addEventListener:(name,fn)=>events[name]=fn};
class FormDataMock{append(){}}
const document={createElement:type=>{const x={style:{},files:[{name:'story.pdf'}],click(){}};if(type==='input')picker=x;return x;}};
const context=vm.createContext({app,api,document,FormData:FormDataMock,URLSearchParams,alert(){}});
vm.runInContext(fs.readFileSync(new URL('../custom_nodes/ComfyUI-Afterglow-Studio/web/upload.js', import.meta.url),'utf8').replace(/^import.*;\n/gm,''),context);
function Node(){this.widgets=[];this.options={};this.size=[360,250];}
Node.prototype.addWidget=function(type,name,value,callback,options){const w={type,name,value,callback,options:options||{}};this.widgets.push(w);return w;};
Node.prototype.addDOMWidget=function(){};Node.prototype.setSize=function(s){this.size=s;};
await extension.beforeRegisterNodeDef(Node,{name:'StudioSource'});
const source=new Node();source.addWidget('combo','source_file','old.png',null,{values:['old.png']});source.onNodeCreated();
source.widgets.find(w=>w.type==='button').callback();await picker.onchange();assert.equal(source.widgets[0].value,'studio_uploads/file.pdf');assert.equal(source.title,'Storyboard: story.pdf');
response={ok:false,data:{error:'Invalid PDF'}};source.widgets.find(w=>w.type==='button').callback();await picker.onchange();assert.equal(source.widgets[0].value,'studio_uploads/file.pdf');
function Director(){Node.call(this);}Director.prototype=Object.create(Node.prototype);Director.prototype.constructor=Director;
await extension.beforeRegisterNodeDef(Director,{name:'StudioFilm'});const director=new Director();director.onNodeCreated();
extension.setup();events['afterglow.studio.progress']({detail:{node_id:'2',stage:'video',text:'Shot 8/18'}});assert.equal(director.widgets.find(w=>w.name==='progress').value,'video: Shot 8/18');
director.onExecuted({studio_video:[{filename:'master.mp4',subfolder:'autofilm_test',type:'output'}]});assert.ok(director.afterglowVideo.src.includes('filename=master.mp4'));assert.ok(director.afterglowVideo.src.includes('type=output'));assert.equal(director.afterglowVideo.controls,true);
console.log('PASS frontend upload selection, failed-upload preservation, progress events, local video player wiring (DOM/API stubs)');
