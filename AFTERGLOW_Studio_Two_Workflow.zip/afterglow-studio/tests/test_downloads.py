"""No GPU/model downloads. Exercise resume, integrity and profile config commits."""
import hashlib,importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import download_models as dm
import model_manager as mm

class Downloads(unittest.TestCase):
    def test_resume_integrity_and_receipt(self):
        payload=b'correct model bytes';model={'size_bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'url':'https://example.invalid/weight'}
        class Response:
            status=206;headers={'Content-Range':'bytes 5-18/19'}
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,size):
                if getattr(self,'done',False):return b''
                self.done=True;return payload[5:]
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)/'model';dest.with_name('model.part').write_bytes(payload[:5])
            with patch.object(dm.urllib.request,'urlopen',return_value=Response()) as opened:dm.download(model,dest)
            self.assertEqual(opened.call_args.args[0].get_header('Range'),'bytes=5-')
            self.assertEqual(dest.read_bytes(),payload)
            with patch.object(dm,'digest',side_effect=AssertionError('Unnecessary hash')),patch.object(dm.urllib.request,'urlopen',side_effect=AssertionError('Unnecessary download')):dm.download(model,dest)
            dest.write_bytes(b'x'*len(payload))
            with self.assertRaises(RuntimeError):dm.download(model,dest)

    def test_profile_filters_and_atomic_ready(self):
        repos=list(mm.ROLES)+['google/siglip2-base-patch16-512','laion/larger_clap_general']
        for profile in mm.PROFILES:
            with tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);cfgpath=root/'config.json'
                config={'models':{},'comfy_root':tmp,'hub_cache':str(root/'hub'),'model_revisions':[{'repo':r,'revision':'abc'} for r in repos], 'native_models':{'models':[{'repo':'Comfy-Org/MiniMax-H3','directory':'a','filename':'h3'},{'repo':'Qwen/Image','directory':'b','filename':'qwen'}]}}
                cfgpath.write_text(json.dumps(config));seen=[];native=[]
                def snapshot(repo,**kw):
                    seen.append(repo);p=root/'hub'/repo.replace('/','--')/'snapshots/abc';p.mkdir(parents=True,exist_ok=True);return str(p)
                fake=types.SimpleNamespace(snapshot_download=snapshot)
                with patch.dict(sys.modules,{'huggingface_hub':fake}),patch.object(sys,'argv',['manager','--config',str(cfgpath),'--profile',profile]),patch.object(mm,'download',side_effect=lambda m,p:native.append(m['filename'])):mm.main()
                cfg=json.loads(cfgpath.read_text());self.assertIn(profile,cfg['ready_profiles'])
                self.assertEqual('h3' in native,profile!='graphics')
                self.assertEqual('tencent/HunyuanVideo-Foley' in seen,profile in ('film','full'))
                self.assertEqual('ZhengPeng7/BiRefNet_HR' in seen,profile!='film')
                self.assertIn('arabic_tts',cfg['models'])

if __name__=='__main__':unittest.main()
