"""CPU verification. AI model boundaries are stubbed explicitly; no quality claim."""
import contextlib,copy,importlib.util,json,shutil,sys,tempfile,unittest
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parents[1];CODE=ROOT/'custom_nodes/ComfyUI-Afterglow-Studio';sys.path.insert(0,str(CODE))
import contracts,graphs,engine,finish
from common import atomic_json,write_wav,ffmpeg,ingest

def bible():
    ref={'asset':'A000','bbox':[0,0,1000,1000]}
    return {'title_ar':'الوهج الأخير','style':'restrained night lighting, textured surfaces','story_arc':'arrival, recognition, departure','characters':[{'id':'c1','description':'adult man, dark curly hair','wardrobe':'black jacket','voice_description':'warm adult voice','anchor':ref}],'brand':{'name':'TEST','palette':['#101A22','#F3EFE5','#E4AC6A'],'product':ref,'logo':None}}

def make_shots(ds):
    return [{'index':i,'duration':d,'title':str(i),'scene':{'asset':'A000','bbox':[0,0,1000,1000]},'subjects':[],'image_prompt':'empty night backdrop','motion_prompt':'slow push','foley_prompt':'wind, no music or speech','continuity':'protagonist continues toward the doorway','speech':{'mode':'voiceover','speaker':'narrator','text_ar':'بعض الذكريات تبقى معنا'} if i==1 else None,'layout':{'headline_ar':'تفاصيل تستحق التأمل','body_ar':'حضور هادئ وتصميم واضح','motion':contracts.MOTIONS[(i-1)%len(contracts.MOTIONS)]}} for i,d in enumerate(ds,1)]

class Contracts(unittest.TestCase):
    def test_all_timelines(self):
        for d in range(15,3601):self.assertEqual(sum(contracts.schedule(d)),d)
    def test_plan_guards(self):
        intake={'assets':[{'id':'A000'}]};b=bible();s=make_shots([4,6,8])
        contracts.validate_bible(b,intake,'design');contracts.validate_shots(s,intake,b,[4,6,8],mode='design')
        for mutation in ['english','unknown','multi_speaker','duration','path']:
            bad=copy.deepcopy(s)
            if mutation=='english':bad[0]['speech']['text_ar']='Hello'
            if mutation=='unknown':bad[0]['subjects']=['c100']
            if mutation=='multi_speaker':bad[0]['speech'].update(mode='dialogue',speaker='c1');bad[0]['subjects']=[]
            if mutation=='duration':bad[0]['duration']=7
            if mutation=='path':bad[0]['scene']['asset']='../../bad'
            with self.assertRaises(ValueError):contracts.validate_shots(bad,intake,b,[4,6,8],mode='design')
    def test_quality_gate(self):
        candidates=[{'id':'a'},{'id':'b'}];scores={'a':{'score':10,'hard_reject':True},'b':{'score':7,'hard_reject':False}}
        self.assertIsNone(engine.select(candidates,scores,7.5));scores['b']['score']=8;self.assertEqual(engine.select(candidates,scores,7.5)['id'],'b')
    def test_frame_grid_and_links(self):
        for d in range(4,13):
            g=graphs.h3('Arabic shot',['a.png','b.png'],'a.mkv',1,768,1344,d,audio='s.wav',first_frame='a.png')
            cond=next(n for n in g.values() if n['class_type']=='MiniMaxH3ReferenceToVideo')
            self.assertGreaterEqual(cond['inputs']['length'],d*24);self.assertEqual(cond['inputs']['length']%17,5)
            for n in g.values():
                for v in n['inputs'].values():
                    if isinstance(v,list):self.assertIn(v[0],g)
            self.assertFalse(any(n['class_type'] in ('VAEDecodeAudio','SaveAudio','SaveVideo') for n in g.values()))

class Orchestration(unittest.TestCase):
    def test_film_and_design(self):
        with tempfile.TemporaryDirectory(prefix='studio_test_') as tmp:
            root=Path(tmp);inp=root/'input';out=root/'output';inp.mkdir();out.mkdir()
            source=inp/'source.png';im=Image.new('RGBA',(270,480),(12,20,30,255));draw=ImageDraw.Draw(im);draw.rounded_rectangle((85,100,185,360),20,fill=(212,176,105));im.save(source)
            config={'version':2,'input_dir':str(inp),'output_dir':str(out)}
            original={k:getattr(engine,k) for k in ['task','submit','comfy_worker']};formats=engine.FORMATS
            # Reduced dimensions exercise the real renderer affordably. The exact
            # 1080x1920 / 90s acceptance is a separate smoke test.
            engine.FORMATS={'Test':(144,256,270,480)}
            calls=[];last_plan={}
            def fake_task(cfg,script,role,data,job,name):
                file=Path(job)/(name+'.json')
                if file.exists():return json.loads(file.read_text())
                calls.append(name)
                if name=='bible':r=bible()
                elif name=='plan':r={'title_ar':data['bible']['title_ar'],'bible':data['bible'],'outline':{'chapters':['resolved test arc']},'shots':make_shots(data['durations']),'duration':sum(data['durations'])};last_plan['value']=r
                elif name=='casting':r={'narrator':'synthetic_fixture.wav'}
                elif name=='speech':
                    r={};Path(data['directory']).mkdir(parents=True,exist_ok=True)
                    for s in data['plan']['shots']:
                        if s['speech']:
                            path=Path(data['directory'])/f'{s["index"]}.wav';a=np.zeros((s['duration']*48000,2),np.float32);n=48000;a[14400:14400+n]=(.08*np.sin(np.arange(n)*2*np.pi*170/48000))[:,None];write_wav(path,a);r[str(s['index'])]=str(path)
                elif '_critic_' in name or name=='delivery_critic':
                    low=name=='video_critic_round_0'
                    r={x['id']:{'score':6.8 if low else 8.2,'hard_reject':False,'issues':['synthetic test requests a retry'] if low else []} for x in data['items']}
                elif name=='brand_cutouts':r=data['assets']
                elif name=='foley':r=finish.design_sfx(data['plan']['shots'],data['directory'],1)
                else:raise AssertionError(name)
                atomic_json(file,r);return r
            @contextlib.contextmanager
            def fake_worker(cfg,job):yield 'local-stub',{}
            def fake_submit(base,info,g,job,label):
                calls.append(label)
                for n in g.values():
                    v=n['inputs']
                    if n['class_type']=='StudioWriteImage':
                        p=inp/v['relative_path'];p.parent.mkdir(parents=True,exist_ok=True);Image.new('RGB',(144,256),(18,29,39)).save(p)
                    if n['class_type']=='StudioWriteFrames':
                        p=out/v['relative_path'];p.parent.mkdir(parents=True,exist_ok=True)
                        ffmpeg(['-y','-f','lavfi','-i',f'color=c=0x121d27:s=144x256:r=24:d={v["duration"]}','-an','-c:v','ffv1','-pix_fmt','yuv444p',str(p)])
                return {}
            engine.task=fake_task;engine.submit=fake_submit;engine.comfy_worker=fake_worker
            try:
                for mode in ['film','design']:
                    opts={'source':str(source),'project':'test_'+mode,'episode':1,'duration':15,'format':'Test','quality':'Production','brief':'Arabic production test','edit_pack':False,'seed':1,'mode':mode,'background':'Graphic motion'}
                    result=engine.production(config,opts);finish.checked_video(result['master'],15,270,480)
                    if mode=='film':self.assertTrue(any('video_0001_5'==x for x in calls))
                    count=len(calls);again=engine.production(config,opts);self.assertEqual(result,again);self.assertEqual(len(calls),count)
                    oldanchors=(out/'studio_projects'/opts['project']/'anchors.json').read_bytes()
                    opts['episode']=2;result=engine.production(config,opts)
                    self.assertEqual(oldanchors,(out/'studio_projects'/opts['project']/'anchors.json').read_bytes())
                    context=json.loads((Path(result['job_directory'])/'context.json').read_text());self.assertEqual(context[0]['episode'],1)
                    self.assertEqual(calls.count('casting'),2 if mode=='design' else 1)
                    timeline=json.loads((Path(result['job_directory'])/'timeline.json').read_text());self.assertEqual(timeline['frames'],360)
                    self.assertTrue((Path(result['job_directory'])/'Arabic.srt').read_text().find('بعض')>=0)
            finally:
                for k,v in original.items():setattr(engine,k,v)
                engine.FORMATS=formats

if __name__=='__main__':unittest.main(verbosity=2)
