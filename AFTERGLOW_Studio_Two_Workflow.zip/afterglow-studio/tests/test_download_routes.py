"""Exercise real background process start/status/cancel with a tiny local fixture."""
import asyncio,importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch

class Routes:
    def get(self,*a):return lambda fn:fn
    def post(self,*a):return lambda fn:fn

class RouteTests(unittest.TestCase):
    def test_start_reject_duplicate_cancel(self):
        code=Path(__file__).resolve().parents[1]/'custom_nodes/ComfyUI-Afterglow-Studio/download_routes.py'
        spec=importlib.util.spec_from_file_location('download_routes_fixture',code);mod=importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules,{'server':types.SimpleNamespace(PromptServer=types.SimpleNamespace(instance=types.SimpleNamespace(routes=Routes())))}):spec.loader.exec_module(mod)
        class Request:
            headers={};host='localhost'
            async def json(self):return {'profile':'graphics'}
        with tempfile.TemporaryDirectory() as tmp:
            mod.HERE=Path(tmp);(mod.HERE/'installer').mkdir()
            (mod.HERE/'installer/model_manager.py').write_text('import time\nprint("fixture download",flush=True)\ntime.sleep(30)\n')
            (mod.HERE/'config.json').write_text(json.dumps({'python':{'vision':sys.executable},'ready_profiles':[]}))
            async def exercise():
                self.assertEqual((await mod.start(Request())).status,200)
                self.assertTrue(mod.state()['running'])
                self.assertEqual((await mod.start(Request())).status,409)
                self.assertEqual((await mod.cancel(Request())).status,200)
            try:
                asyncio.run(exercise());mod.process.wait(timeout=5);self.assertFalse(mod.state()['running'])
            finally:
                if mod.process and mod.process.poll() is None:mod.process.kill();mod.process.wait()
                if mod.log_handle:mod.log_handle.close()

if __name__=='__main__':unittest.main()
