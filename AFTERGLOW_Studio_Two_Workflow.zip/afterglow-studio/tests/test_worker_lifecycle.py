import pathlib,sys,json,os,time,signal
pack=pathlib.Path(__file__).resolve().parents[1]/'custom_nodes/ComfyUI-Afterglow-Studio';sys.path.insert(0,str(pack));import runtime
import tempfile,shutil
root=pathlib.Path(tempfile.mkdtemp(prefix='studio_lifecycle_'))
(root/'main.py').write_text('''import argparse,json,os\nfrom http.server import HTTPServer,BaseHTTPRequestHandler\np=argparse.ArgumentParser();p.add_argument("--listen");p.add_argument("--port",type=int);a,extra=p.parse_known_args()\nclass Handler(BaseHTTPRequestHandler):\n def do_GET(self):\n  b=json.dumps({"pid":os.getpid()}).encode();self.send_response(200);self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)\n def log_message(self,*args):pass\nHTTPServer((a.listen,a.port),Handler).serve_forever()\n''')
config={'python':{'comfy':sys.executable},'comfy_root':str(root),'input_dir':str(root),'output_dir':str(root),'hub_cache':str(root/'hub')}
for deliberate_error in [False,True]:
 pid=None
 try:
  with runtime.comfy_worker(config,root) as (base,info):
   assert base.startswith('http://127.0.0.1:');pid=info['pid'];os.kill(pid,0)
   if deliberate_error:raise ValueError('Synthetic interrupted stage')
 except ValueError:
  assert deliberate_error
 assert pid is not None
 try:os.kill(pid,0);raise AssertionError('Owned worker survived context cleanup')
 except ProcessLookupError:pass
print('PASS owned worker startup, loopback handshake, normal cleanup and exception cleanup (fake model server)')

shutil.rmtree(root)
