"""Single notebook entry point. Software only: models are downloaded inside ComfyUI."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--comfy-root',type=Path,default=Path('/workspace/ComfyUI'));p.add_argument('--python',default=sys.executable);a=p.parse_args()
comfy=a.comfy_root.absolute()
command=[sys.executable,str(ROOT/'tools/setup_local.py'),'--comfy-root',str(comfy),'--runtime-root',str(comfy.parent/'afterglow-data'),'--skip-models','--replace-pack']
if not (comfy/'main.py').exists() or (comfy/'.afterglow-managed').exists():command+=['--install-comfy']
else:
    native=next((str(x) for x in (comfy/'.venv/bin/python',comfy/'venv/bin/python') if x.is_file()),a.python)
    command+=['--comfy-python',native]
print('Software setup only. Models will be downloaded from the workflow buttons.',flush=True)
subprocess.run(command,check=True)
print('Ready. Restart ComfyUI, import a Studio workflow, then click Download / resume models.',flush=True)
