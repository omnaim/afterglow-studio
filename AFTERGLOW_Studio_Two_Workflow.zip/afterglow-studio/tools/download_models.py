"""Download only one model profile, resume partial files, verify their LFS SHA-256."""
import argparse
import hashlib
import json
import os
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def download(model,destination):
    destination.parent.mkdir(parents=True,exist_ok=True)
    receipt=destination.with_name(destination.name+'.verified.json')
    def record():
        stat=destination.stat();receipt.write_text(json.dumps({'sha256':model['sha256'],'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}))
    if destination.is_file():
        stat=destination.stat()
        if receipt.exists():
            try:
                if json.loads(receipt.read_text())=={'sha256':model['sha256'],'size':model['size_bytes'],'mtime_ns':stat.st_mtime_ns} and stat.st_size==model['size_bytes']:
                    print(f'Already verified: {destination.name}',flush=True);return
            except (ValueError,OSError):pass
        if destination.stat().st_size==model['size_bytes'] and digest(destination)==model['sha256']:
            record();print(f'Already verified: {destination.name}',flush=True);return
        raise RuntimeError(f'Existing {destination} has wrong size/hash; move it aside before retrying.')
    partial=destination.with_name(destination.name+'.part')
    offset=partial.stat().st_size if partial.exists() else 0
    if offset>model['size_bytes']:
        raise RuntimeError(f'Oversized partial file: {partial}')
    if offset<model['size_bytes']:
        request=urllib.request.Request(model['url'])
        if offset:request.add_header('Range',f'bytes={offset}-')
        token=os.environ.get('HF_TOKEN')
        if token:request.add_header('Authorization','Bearer '+token)
        with urllib.request.urlopen(request,timeout=120) as response:
            # A server that ignores Range must restart the local partial file.
            append=offset>0 and response.status==206
            if append and not response.headers.get('Content-Range','').startswith(f'bytes {offset}-'):
                raise RuntimeError('Server returned a mismatched resume range.')
            if not append:offset=0
            print(f'Downloading {destination.name} ({model["size_bytes"]/1e9:.2f} GB), resume={offset}',flush=True)
            reported=offset
            with partial.open('ab' if append else 'wb') as f:
                while True:
                    block=response.read(8*1024*1024)
                    if not block:break
                    f.write(block);offset+=len(block)
                    if offset-reported>=256*1024*1024:
                        print(f'{destination.name}: {offset/1e9:.2f}/{model["size_bytes"]/1e9:.2f} GB',flush=True);reported=offset
    if partial.stat().st_size!=model['size_bytes'] or digest(partial)!=model['sha256']:
        raise RuntimeError(f'Download failed integrity verification: {partial}. Do not load this file.')
    os.replace(partial,destination);record()
    print(f'Verified: {destination.name}',flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--comfy-root',type=Path,required=True)
    p.add_argument('--profile',choices=['cinema'],default='cinema')
    p.add_argument('--list',action='store_true',help='Print requirements without downloading.')
    a=p.parse_args()
    if not (a.comfy_root/'main.py').is_file():p.error('Expected ComfyUI root with main.py.')
    models=[m for m in json.loads((ROOT/'models_manifest.json').read_text())['models'] if a.profile in m['profiles']]
    print(f'{a.profile}: {len(models)} files, {sum(m["size_bytes"] for m in models)/1e9:.2f} GB total (decimal).',flush=True)
    for m in models:
        path=a.comfy_root/'models'/m['directory']/m['filename']
        if a.list:print(path)
        else:download(m,path)
    if not a.list:print('Model profile ready.')

if __name__=='__main__':main()
