"""Pinned, resumable model downloads. Invoked by the ComfyUI download panel."""
import argparse
import fcntl
import json
import os
from pathlib import Path
from download_models import download

PROFILES=('film','design','graphics','full')
ROLES={'Qwen/Qwen3.8-27B':'vision','ZhengPeng7/BiRefNet_HR':'segmentation','Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign':'voice_design','ResembleAI/chatterbox':'arabic_tts','openai/whisper-large-v3':'asr','tencent/HunyuanVideo-Foley':'foley'}
FOLEY={'tencent/HunyuanVideo-Foley','google/siglip2-base-patch16-512','laion/larger_clap_general'}

def selected(repo,profile):
    if repo in FOLEY:return profile in ('film','full')
    if repo=='ZhengPeng7/BiRefNet_HR':return profile in ('design','graphics','full')
    return True

def atomic(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2));os.replace(temp,path)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True);parser.add_argument('--profile',choices=PROFILES,required=True)
    args=parser.parse_args();root=args.config.parent
    # OS releases this lock even if a pod or download process dies.
    with (root/'models.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        cfg=json.loads(args.config.read_text());profile=args.profile
        os.environ['HF_HUB_CACHE']=cfg['hub_cache']
        os.environ.pop('HF_HUB_OFFLINE',None);os.environ.pop('TRANSFORMERS_OFFLINE',None)
        from huggingface_hub import snapshot_download
        for model in cfg['native_models']['models']:
            if profile=='graphics' and 'MiniMax' in model['repo']:continue
            download(model,Path(cfg['comfy_root'])/'models'/model['directory']/model['filename'])
        for item in cfg['model_revisions']:
            repo=item['repo']
            if not selected(repo,profile):continue
            options={}
            if repo=='ResembleAI/chatterbox':options['allow_patterns']=['ve.pt','s3gen.pt','t3_mtl23ls_v3.safetensors','grapheme_mtl_merged_expanded_v1.json','conds.pt','Cangjie5_TC.json','README.md']
            elif repo=='openai/whisper-large-v3':options['ignore_patterns']=['*.bin','*.msgpack','*fp32*','*.h5']
            elif repo=='tencent/HunyuanVideo-Foley':options['ignore_patterns']=['hunyuanvideo_foley_xl.pth','*.mp4']
            print('Downloading / checking '+repo,flush=True)
            path=snapshot_download(repo,revision=item['revision'],**options)
            if repo in ROLES:cfg['models'][ROLES[repo]]=path
            else:
                refs=Path(path).parents[1]/'refs';refs.mkdir(exist_ok=True);(refs/'main').write_text(item['revision'])
            atomic(args.config,cfg)
        ready=set(cfg.get('ready_profiles',[]));ready.add(profile)
        if profile=='full':ready.update(PROFILES)
        if profile=='design':ready.add('graphics')
        cfg['ready_profiles']=sorted(ready);atomic(args.config,cfg)
        print('READY: '+profile+'. You can run the workflow now.',flush=True)

if __name__=='__main__':main()
