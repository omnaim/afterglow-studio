"""One-time Linux GPU setup. Install model workers in separate environments.

No paid service or inference API is used. Internet is used only during installation
and model downloads. Existing ComfyUI Python/torch is not upgraded by this script.
"""
import argparse
import hashlib
from datetime import datetime, timezone
import json
import os
import shutil
import subprocess
import sys
import tomllib
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REVISIONS={
    'foley':('https://github.com/Tencent-Hunyuan/HunyuanVideo-Foley.git','df7b005b5023df2a9b73e1d66dd51d452799884e'),
    'chatterbox':('https://github.com/resemble-ai/chatterbox.git','5de7a54aa4e5e2baadb0182dde554908b48b85c2'),
    'qwen_tts':('https://github.com/QwenLM/Qwen3-TTS.git','022e286b98fbec7e1e916cb940cdf532cd9f488e')}
TRANSFORMERS_REV='78633ef9ff2338284e0c9da2218381b7ed755bc4'
COMFY_REV='14c553159994b626738c392eb99d295ea3d683c1'


def run(command,env=None):
    command=[str(x) for x in command]
    if command[1:4]==['-m','pip','install']:
        constraint=Path(command[0]).absolute().parent.parent/'afterglow-torch-constraints.txt'
        if constraint.exists():command.extend(['--constraint',str(constraint)])
    print('Running: '+' '.join(command),flush=True)
    subprocess.run([str(x) for x in command],check=True,env=env)


def venv(base,path):
    if not (path/'bin/python').is_file():run([base,'-m','venv',path])
    python=path/'bin/python';run([python,'-m','pip','install','--upgrade','pip','wheel','setuptools'])
    return python


def clone(url,path,revision):
    if not (path/'.git').is_dir():
        if path.exists() and any(path.iterdir()):raise RuntimeError(f'{path} exists and is not the expected git checkout. Move it aside before setup.')
        path.mkdir(parents=True,exist_ok=True);run(['git','init',path]);run(['git','-C',path,'remote','add','origin',url])
    actual=subprocess.run(['git','-C',str(path),'rev-parse','HEAD'],capture_output=True,text=True)
    if actual.returncode==0 and actual.stdout.strip()==revision:return
    dirty=subprocess.run(['git','-C',str(path),'status','--porcelain'],capture_output=True,text=True,check=True).stdout.strip()
    if dirty:raise RuntimeError(f'{path} has local changes; setup will not overwrite them.')
    run(['git','-C',path,'fetch','--depth','1','origin',revision]);run(['git','-C',path,'checkout','--detach',revision])


def torch_install(python,index,version,build_image=False):
    # Matching torch/torchvision/torchaudio triplet for the default modern CUDA build.
    vision={'2.10.0':'0.25.0','2.9.1':'0.24.1','2.8.0':'0.23.0','2.7.1':'0.22.1','2.6.0':'0.21.0'}[version]
    constraint=Path(python).absolute().parent.parent/'afterglow-torch-constraints.txt'
    constraint.write_text(f'torch=={version}\ntorchvision=={vision}\ntorchaudio=={version}\n')
    gpu_probe='' if build_image else '; assert torch.cuda.is_available(); torch.ones(1,device="cuda").sum().item()'
    probe=subprocess.run([str(python),'-c',f'import torch,torchvision,torchaudio; assert torch.__version__.split("+")[0]=={version!r}; assert torchvision.__version__.split("+")[0]=={vision!r}; assert torchaudio.__version__.split("+")[0]=={version!r}'+gpu_probe],capture_output=True)
    if probe.returncode==0:
        print('Reusing working PyTorch triplet in '+str(python),flush=True);return
    run([python,'-m','pip','install',f'torch=={version}',f'torchaudio=={version}',f'torchvision=={vision}','--index-url',index])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--comfy-root',type=Path,required=True)
    p.add_argument('--install-comfy',action='store_true',help='Create an isolated pinned ComfyUI checkout and .venv in a NEW directory.')
    p.add_argument('--comfy-python',type=Path,help='Existing ComfyUI Python executable; auto-detected when possible.')
    p.add_argument('--input-dir',type=Path);p.add_argument('--output-dir',type=Path)
    p.add_argument('--runtime-root',type=Path,help='Persistent volume for extra models and isolated environments.')
    p.add_argument('--base-python',default=sys.executable,help='Python 3.11 or 3.12 used to create the extra environments.')
    p.add_argument('--torch-version',choices=['2.10.0','2.9.1','2.8.0','2.7.1','2.6.0'],default='2.10.0')
    p.add_argument('--torch-index',default='https://download.pytorch.org/whl/cu128')
    p.add_argument('--build-image',action='store_true',help='CPU Docker build: skip GPU execution probes; runtime boot checks every worker before downloading models.')
    p.add_argument('--skip-models',action='store_true',help='Install software only; download models using the buttons inside ComfyUI.')
    p.add_argument('--repair',action='store_true',help='Ignore dependency checkpoint and repair software.')
    p.add_argument('--replace-pack',action='store_true',help='Update matching supplied custom-node files after backing up previous versions.')
    a=p.parse_args()
    if a.build_image and not a.skip_models:p.error('--build-image requires --skip-models')
    if sys.platform!='linux':p.error('This automated rented-GPU setup targets Linux.')
    comfy=a.comfy_root.resolve()
    runtime=(a.runtime_root or comfy.parent/(comfy.name+'_studio_runtime')).resolve()
    runtime.mkdir(parents=True,exist_ok=True)
    os.environ['PIP_CACHE_DIR']=str(runtime/'cache/pip')
    os.environ['HF_HUB_CACHE']=str(runtime/'hub')
    os.environ['PIP_DISABLE_PIP_VERSION_CHECK']='1'

    if a.install_comfy:
        if comfy.exists() and any(comfy.iterdir()) and not (comfy/'.afterglow-managed').exists():p.error('Existing unmanaged ComfyUI: rerun without --install-comfy.')
        comfy.mkdir(parents=True,exist_ok=True)
        clone('https://github.com/Comfy-Org/ComfyUI.git',comfy,COMFY_REV)
        (comfy/'.afterglow-managed').touch()
        host_python=comfy/'.venv/bin/python'
        host_stamp=runtime/'comfy_software.json'
        host_signature=hashlib.sha256(((comfy/'requirements.txt').read_text()+a.torch_version+a.torch_index).encode()).hexdigest()
        host_ready=False
        if host_stamp.exists() and host_python.exists() and not a.repair:
            old=json.loads(host_stamp.read_text())
            host_ready=old.get('signature')==host_signature and old.get('freeze')==subprocess.check_output([str(host_python),'-m','pip','freeze'],text=True)
        if not host_ready:
            host_python=venv(a.base_python,comfy/'.venv');torch_install(host_python,a.torch_index,a.torch_version,a.build_image)
            run([host_python,'-m','pip','install','-r',comfy/'requirements.txt'])
            host_stamp.write_text(json.dumps({'signature':host_signature,'freeze':subprocess.check_output([str(host_python),'-m','pip','freeze'],text=True)}))
        a.comfy_python=host_python
    if not (comfy/'main.py').is_file() or not (comfy/'custom_nodes').is_dir():p.error('ComfyUI root must contain main.py and custom_nodes.')
    for executable in ['ffmpeg','ffprobe','git']:
        if not shutil.which(executable):p.error(f'{executable} must be installed and on PATH.')
    native=a.comfy_python
    if native is None:
        native=next((x for x in [comfy/'.venv/bin/python',comfy/'venv/bin/python',Path(sys.executable)] if x.is_file()),None)
    if native is None or not native.is_file():p.error('Specify --comfy-python for the existing ComfyUI interpreter.')
    native=native.absolute() # Preserve the venv symlink path; resolving it would select system Python.
    if not a.build_image:check=subprocess.run([str(native),'-c','import torch; assert torch.cuda.is_available(), "CUDA unavailable in ComfyUI Python"; print(torch.__version__, torch.cuda.get_device_name(0))'],check=True)
    help_result=subprocess.run([str(native),str(comfy/'main.py'),'--help'],cwd=comfy,capture_output=True,text=True,check=True)
    for flag in ['--offline','--cache-none','--input-directory','--output-directory']:
        if flag not in help_result.stdout:raise RuntimeError(f'This ComfyUI build lacks {flag}. Update ComfyUI before setup; no models have been downloaded yet.')
    checks={'comfy_extras/nodes_minimax_h3.py':['class MiniMaxH3ReferenceToVideo','class MiniMaxH3AddGuide'],'comfy_extras/nodes_qwen.py':['class TextEncodeQwenImage21']}
    for file,needles in checks.items():
        code=(comfy/file).read_text() if (comfy/file).exists() else ''
        if not all(n in code for n in needles):raise RuntimeError('ComfyUI lacks required Studio nodes. Use a new directory with --install-comfy or update your core to the documented revision.')
    version=subprocess.check_output([a.base_python,'-c','import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'],text=True).strip()
    if version not in ['3.11','3.12']:p.error('--base-python must be Python 3.11 or 3.12.')
    inputdir=(a.input_dir or comfy/'input').resolve();outputdir=(a.output_dir or comfy/'output').resolve()
    inputdir.mkdir(parents=True,exist_ok=True);outputdir.mkdir(parents=True,exist_ok=True)
    runtime=(a.runtime_root or comfy.parent/(comfy.name+'_studio_runtime')).resolve();runtime.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env.update(HF_HUB_CACHE=str(runtime/'hub'),HF_HUB_DISABLE_TELEMETRY='1')
    # Installation must be allowed to download; inference later forces both offline flags.
    env.pop('HF_HUB_OFFLINE',None);env.pop('TRANSFORMERS_OFFLINE',None)
    checkpoint=runtime/'software_ready.json'
    signature=hashlib.sha256((Path(__file__).read_text()+str(a.torch_version)+a.torch_index+str(native)+str(a.base_python)).encode()).hexdigest()
    cached=json.loads(checkpoint.read_text()) if checkpoint.exists() else {}
    reuse=not a.repair and cached.get('signature')==signature
    if reuse:
        for exe,expected in cached.get('freezes',{}).items():
            try:
                actual=subprocess.check_output([exe,'-m','pip','freeze'],text=True)
                if actual!=expected:reuse=False;break
            except (OSError,subprocess.CalledProcessError):reuse=False;break
    if reuse:
        py=cached['python'];repos=cached['repos']
        print('Verified software checkpoint: skipping dependency installation.',flush=True)
    else:
        py={}
        for role in ['vision','voice_design','arabic','foley','segment']:
            python=venv(a.base_python,runtime/'envs'/role);torch_install(python,a.torch_index,a.torch_version,a.build_image);py[role]=str(python)
        repos={}
        for role,(url,rev) in REVISIONS.items():
            destination=runtime/'repos'/role
            clone(url,destination,rev);repos[role]=str(destination)
        run([py['vision'],'-m','pip','install',f'git+https://github.com/huggingface/transformers.git@{TRANSFORMERS_REV}','accelerate','pymupdf','pillow','numpy','soundfile','sentencepiece'])
        run([py['voice_design'],'-m','pip','install',repos['qwen_tts']])
        run([py['arabic'],'-m','pip','install','--no-deps',repos['chatterbox']])
        # Upstream pins torch 2.6. New GPU architectures may require a newer CUDA
        # build, so keep our explicit triplet and install its other pinned dependencies.
        deps=tomllib.loads((Path(repos['chatterbox'])/'pyproject.toml').read_text())['project']['dependencies']
        deps=[d for d in deps if not d.split('=',1)[0].split('>',1)[0].strip().startswith(('torch','torchaudio'))]
        run([py['arabic'],'-m','pip','install',*deps,'soundfile'])
        run([py['foley'],'-m','pip','install','numpy==1.26.4','scipy','diffusers','timm','accelerate','transformers==4.57.3','sentencepiece',
             'git+https://github.com/descriptinc/audiotools','pillow','av','einops','pyyaml','omegaconf','easydict','loguru','tqdm','pandas','pyarrow','soundfile','silero-vad==6.2.3'])
        run([native,'-m','pip','install','pymupdf','pillow','numpy'])
        run([py['segment'],'-m','pip','install','transformers==4.57.3','timm','kornia','einops','pillow','numpy','pymupdf'])
    for role,exe in py.items():
        run([exe,'-c',f'import torch,torchvision,torchaudio; assert torch.__version__.split("+")[0]=={a.torch_version!r}; assert torchaudio.__version__.split("+")[0]=={a.torch_version!r}; print("Torch imports/version checked: {role}")'])
    model_revisions=json.loads((ROOT/'local_model_revisions.json').read_text())
    configpath=comfy/'custom_nodes/ComfyUI-Afterglow-Studio/config.json'
    previous=json.loads(configpath.read_text()) if configpath.exists() else {}
    config={'version':2,'comfy_root':str(comfy),'input_dir':str(inputdir),'output_dir':str(outputdir),
            'python':{**py,'comfy':str(native)},'models':previous.get('models',{}),'ready_profiles':previous.get('ready_profiles',[]) if previous.get('model_revisions')==model_revisions else [],'repos':{'foley':repos['foley']},
            'hub_cache':str(runtime/'hub'),'worker_args':[],'model_revisions':model_revisions,'torch_version':a.torch_version,
            'native_models':json.loads((ROOT/'models_manifest.json').read_text()),'comfy_reference_commit':COMFY_REV}
    for name in ['ComfyUI-Afterglow-Studio']:
        source=ROOT/'custom_nodes'/name;destination=comfy/'custom_nodes'/name
        if destination.exists():
            if not a.replace_pack:raise RuntimeError(f'{destination} already exists. Use --replace-pack to back it up and update it.')
            backup=runtime/'backups'/(name+'_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f'))
            backup.parent.mkdir(exist_ok=True);shutil.copytree(destination,backup)
        shutil.copytree(source,destination,dirs_exist_ok=a.replace_pack,ignore=shutil.ignore_patterns('__pycache__','config.json'))
    configpath=comfy/'custom_nodes/ComfyUI-Afterglow-Studio/config.json';configpath.write_text(json.dumps(config,indent=2))
    assets=configpath.parent/'installer'
    assets.mkdir(exist_ok=True)
    for name in ['download_models.py','model_manager.py']:
        shutil.copy2(ROOT/'tools'/name,assets/name)
    for name in ['models_manifest.json','local_model_revisions.json']:
        shutil.copy2(ROOT/name,configpath.parent/name)
    if not a.skip_models:
        run([py['vision'],assets/'model_manager.py','--config',configpath,'--profile','full'],env=env)
    (inputdir/'studio_uploads').mkdir(exist_ok=True)
    run([py['vision'],'-c','from transformers import Qwen3_5ForConditionalGeneration; import fitz; print("Vision imports OK")'])
    run([py['voice_design'],'-c','from qwen_tts import Qwen3TTSModel; print("Voice design imports OK")'])
    run([py['arabic'],'-c','from chatterbox.mtl_tts import ChatterboxMultilingualTTS; from transformers import WhisperForConditionalGeneration; print("Arabic speech/ASR imports OK")'])
    run([py['foley'],'-c',f'import sys; sys.path.insert(0,{repos["foley"]!r}); from hunyuanvideo_foley.utils.model_utils import load_model; print("Foley imports OK")'])
    for role,exe in py.items():
        with (runtime/(role+'_pip_freeze.txt')).open('w') as log:
            subprocess.run([exe,'-m','pip','freeze'],stdout=log,check=True)
    run([py['vision'],'-c','from PIL import features; assert features.check("raqm"), "Pillow requires RAQM for Arabic typography"'])
    if a.install_comfy:
        host_stamp.write_text(json.dumps({'signature':host_signature,'freeze':subprocess.check_output([str(native),'-m','pip','freeze'],text=True)}))
    freezes={exe:subprocess.check_output([exe,'-m','pip','freeze'],text=True) for exe in [*py.values(),str(native)]}
    tmp=checkpoint.with_suffix('.tmp');tmp.write_text(json.dumps({'signature':signature,'python':py,'repos':repos,'freezes':freezes}));os.replace(tmp,checkpoint)
    print(f'Local setup ready. Restart ComfyUI and open {ROOT/"workflows"}. Upload one PDF/image and Run.',flush=True)


if __name__=='__main__':main()
