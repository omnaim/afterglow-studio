"""GPU-host preflight; optionally run a real 15-second inference acceptance job."""
import argparse,json,subprocess,sys
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True)
    p.add_argument('--smoke-source',type=Path,help='Optional REAL inference test: local source inside ComfyUI/input; creates a 15s Preview.')
    p.add_argument('--mode',choices=['film','design'],default='film');a=p.parse_args()
    cfg=json.loads(a.config.read_text());code=a.config.resolve().parent;sys.path.insert(0,str(code))
    from runtime import comfy_worker,local_env
    from comfy_client import preflight
    from graphs import keyframe,h3
    from common import atomic_json
    report={'config_version':cfg['version'],'checks':[],'inference_run':False}
    for role,exe in cfg['python'].items():
        subprocess.run([exe,'-c','import torch; assert torch.cuda.is_available(); print(torch.__version__)'],check=True,env=local_env(cfg));report['checks'].append(role+' CUDA')
    for m in cfg['native_models']['models']:
        path=Path(cfg['comfy_root'])/'models'/m['directory']/m['filename']
        if not path.exists() or path.stat().st_size!=m['size_bytes']:raise RuntimeError('Missing or incomplete model: '+str(path))
    report['checks'].append('native model presence and expected sizes; installer verifies SHA256')
    job=Path(cfg['output_dir'])/'studio_doctor';job.mkdir(exist_ok=True)
    with comfy_worker(cfg,job) as (base,info):
        preflight(keyframe('test',['placeholder.png'],'doctor/image.png',1,768,1344),info)
        preflight(h3('test',['placeholder.png'],'doctor/video.mkv',1,768,1344,6,audio='placeholder.wav',first_frame='placeholder.png'),info)
    report['checks'].append('live ComfyUI graph/model/schema compatibility')
    if a.smoke_source:
        options={'source':str(a.smoke_source.resolve()),'project':'gpu_acceptance_'+a.mode,'episode':1,'duration':15,'format':'Vertical 9:16','quality':'Preview','brief':'Create a coherent three-shot test from this reference with one short Arabic voiceover line. Preserve the visual style. No music.','edit_pack':False,'seed':9401,'mode':a.mode,'background':'H3 animated background','visual_mode':'Automatic'}
        options_path=job/'smoke_options.json';atomic_json(options_path,options)
        subprocess.run([cfg['python']['vision'],str(code/'engine.py'),'--config',str(a.config.resolve()),'--options',str(options_path)],check=True)
        report['inference_run']=True;report['checks'].append('15s real Preview completed; human visual/Arabic review still required')
    atomic_json(job/'doctor_report.json',report);print(json.dumps(report,indent=2))

if __name__=='__main__':main()
