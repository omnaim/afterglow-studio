"""Build the two ComfyUI UI graphs plus their API equivalents."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def build(kind):
    isfilm=kind=='Film';node='Studio'+kind;project='my_series' if isfilm else 'my_brand'
    values=['Upload a PDF or image']
    widgets=[project,1,90,'Vertical 9:16','Production','Adapt the uploaded reference faithfully. Natural Arabic speech. Preserve the visual style. No music.',True,9401,'fixed']
    if not isfilm:widgets+=['H3 animated background','Automatic']
    names=['project','episode','duration','format','quality','brief','edit_pack','seed']+([] if isfilm else ['background','visual_mode'])
    typed=['STRING','INT','INT','COMBO','COMBO','STRING','BOOLEAN','INT']+([] if isfilm else ['COMBO','COMBO'])
    title='SERIES & MOVIE PRODUCTION' if isfilm else 'MOTION & PRODUCT DESIGN'
    instructions=('Upload a PDF or image, set a project name, then Run. After setup all inference is local. Arabic speech; no music model.\n\n'
                  'Production renders up to six candidates per shot and applies a visual quality gate. Preview renders one take and does not advance the series story.\n\n'
                  'Keep the project name for the same cast/brand; increase episode for the next installment. Use a new project name for a new cast/brand. Default 90 seconds, 9:16; 15–3600 seconds and landscape/square are available.\n\n'
                  'edit_pack adds ProRes master and, for design, alpha overlays. MP4, Arabic SRT, timeline, shots and audio are always retained. Actual model inference requires GPU acceptance testing; automated scores do not certify visual quality.')
    g={'last_node_id':3,'last_link_id':1,'nodes':[
      {'id':1,'type':'StudioSource','pos':[60,160],'size':[360,150],'flags':{},'order':0,'mode':0,'inputs':[],'outputs':[{'name':'source_path','type':'STRING','links':[1],'slot_index':0}],'properties':{'Node name for S&R':'StudioSource'},'widgets_values':values,'title':'01 · Upload your source','color':'#273a44','bgcolor':'#17232a'},
      {'id':2,'type':node,'pos':[490,100],'size':[590,740],'flags':{},'order':1,'mode':0,'inputs':[{'name':'source_path','type':'STRING','link':1}],'outputs':[{'name':'finished_video','type':'VIDEO','links':None,'slot_index':0},{'name':'production_report','type':'STRING','links':None,'slot_index':1}],'properties':{'Node name for S&R':node},'widgets_values':widgets,'title':'02 · '+title,'color':'#3c3430','bgcolor':'#211d1b'},
      {'id':3,'type':'Note','pos':[60,365],'size':[360,460],'flags':{},'order':2,'mode':0,'inputs':[],'outputs':[],'properties':{},'widgets_values':[instructions],'title':'START HERE','color':'#32343a','bgcolor':'#202127'}
    ],'links':[[1,1,0,2,0,'STRING']],'groups':[],'config':{},'extra':{'ds':{'scale':.88,'offset':[35,25]},'afterglow_studio':{'version':2,'mode':'film' if isfilm else 'design','local_only':True,'speech':'ar','music_model':False}},'version':.4}
    filename='01_Series_and_Movie' if isfilm else '02_Motion_and_Product'
    (ROOT/'workflows'/f'{filename}.json').write_text(json.dumps(g,ensure_ascii=False,indent=2))
    literal=widgets[:8]+([] if isfilm else widgets[-2:])
    inputs=dict(zip(names,literal));inputs['source_path']=['1',0]
    api={'1':{'class_type':'StudioSource','inputs':{'source_file':'studio_uploads/your_file.pdf'}},'2':{'class_type':node,'inputs':inputs}}
    (ROOT/'workflows'/f'{filename}_API.json').write_text(json.dumps(api,ensure_ascii=False,indent=2))

if __name__=='__main__':
    build('Film');build('Design')
