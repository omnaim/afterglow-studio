# Model research and production choices

Verified against primary model cards, upstream code and official ComfyUI templates on **12 October 2026 UTC / 13 October in Riyadh**. There is no universal “best model” proven by this project: selection is based on the user's local-only, Arabic, continuity and production requirements. No side-by-side GPU image-quality benchmark was run here.

## Selected implementation

| Job | Selected model/tool | Reason and actual implementation |
|---|---|---|
| Document interpretation, story planning, visual review | **Qwen3.8-27B, BF16** | Current official dense vision-language release. Local Transformers inference, validated JSON output, chapter planning and reference-based candidate scoring. Its official configuration uses `Qwen3_5ForConditionalGeneration`. |
| Keyframes and reference editing | **Qwen-Image-2.1, BF16** | Newer than the previous 2511 editor; native ComfyUI supports multiple image references. This build uses 40-step Euler/simple, CFG 1, original subject references and one canvas image. Full-precision 8B visual/text encoder and the matching 2.1 VAE. |
| Video | **MiniMax H3 Ref2VA, BF16** | Native multimodal reference conditioning fits recurring cast/product work. Native ComfyUI supports image references and audio guides. Uses the full BF16 checkpoint, BF16 Qwen3-VL encoder, official FP16 video VAE and FP32 audio VAE; 20-step reference sampler with high-resolution reference conditioning. |
| Stable synthetic casting | **Qwen3-TTS VoiceDesign 1.7B** | Creates one reusable synthetic voice reference per role. Its English guide recording never enters the film. Arabic is not claimed as a supported VoiceDesign generation language. |
| Exact Arabic speech | **Chatterbox Multilingual V3** | Arabic is supported; a separately generated waveform makes script timing and voice reuse explicit. The waveform is checked with local **Whisper large-v3**, then fed into H3 as an audio guide for visible dialogue. |
| Film sound effects | **HunyuanVideo-Foley XXL** | Conditions physical sound generation on selected video. No music generator. Silero VAD screens unintended speech; this is a heuristic. |
| Product masking | **BiRefNet HR** | A 2048-resolution foreground mask is applied to original pixels. Existing PNG alpha is preserved. The mask does not redraw labels. |
| Typography/editing/delivery | **Pillow/RAQM + FFmpeg + native ComfyUI nodes** | Exact Arabic shaping, deterministic graphic layers, disk-backed shots, audio mastering, H.264/ProRes, alpha overlays, SRT, EDL and JSON edit data. |

H3's publicly released local base is a 768-short-edge model. Its official hosted Context-IR and Regenerate-2K services are **not included**. This build supplies its own local planning/context pipeline and resizes the final SDR delivery to 1080×1920. That must not be confused with the hosted H3 2K regeneration result.

## Other current models reviewed

| Candidate | Finding | Decision |
|---|---|---|
| **LTX-2.5** | Official open weights, updated encoder/decoder and production-oriented audio/video workflows; newer than LTX-2.3. | A strong alternative. H3 was selected here for its reference modalities, documented Arabic support and the native audio-guide route. LTX is not installed or silently used. |
| **FLUX.2 [dev]** | Current multi-reference image editing option with separate commercial-use licensing considerations. | Qwen-Image-2.1 provides the selected current native local editor for this build. |
| **HunyuanVideo-1.5** | Official local video family with lower parameter count and dedicated inference/training tooling. | Retained in the comparison; no extra generator installed because the user prioritized reference consistency over GPU economy. |
| **Wan 2.2** | Established native local workflows, used by the earlier AFTERGLOW package. | Replaced by H3 in this version's video stage. |
| **Fish Audio S2 Pro** | Recent expressive multilingual TTS with Arabic listed. Its public model card carries a research/non-commercial condition. | Not selected as a default for a production-oriented package. Chatterbox supplies the exact Arabic speech track. |
| **SeedVR2 / FlashVSR** | Local diffusion video-restoration/upscaling projects. | Not enabled in the delivery path. Generative restoration can alter faces, labels and intentional texture; this build preserves selected footage and performs a conventional resize. No claim of recovered native 2K/4K detail. |

## Primary sources

- MiniMax H3 model, local/hosted boundary and supported languages: https://github.com/MiniMax-AI/MiniMax-H3
- Native H3 ComfyUI tutorial: https://docs.comfy.org/tutorials/video/minimax/minimax-h3-native
- ComfyUI H3 weights: https://huggingface.co/Comfy-Org/MiniMax-H3
- Qwen3.8-27B model card: https://huggingface.co/Qwen/Qwen3.8-27B
- Qwen-Image-2.1 model card: https://huggingface.co/Qwen/Qwen-Image-2.1
- Native Qwen-Image-2.1 tutorial: https://docs.comfy.org/tutorials/image/qwen/qwen-image-2-1
- LTX-2.5 model card: https://huggingface.co/Lightricks/LTX-2.5
- LTX official inference implementation: https://github.com/Lightricks/LTX-2
- FLUX.2: https://bfl.ai/models/flux-2
- HunyuanVideo-1.5: https://github.com/Tencent-Hunyuan/HunyuanVideo-1.5
- Qwen3-TTS: https://github.com/QwenLM/Qwen3-TTS
- Chatterbox: https://github.com/resemble-ai/chatterbox
- Fish S2 Pro: https://huggingface.co/fishaudio/s2-pro
- Whisper large-v3: https://huggingface.co/openai/whisper-large-v3
- HunyuanVideo-Foley: https://github.com/Tencent-Hunyuan/HunyuanVideo-Foley
- BiRefNet HR: https://huggingface.co/ZhengPeng7/BiRefNet_HR
- SeedVR2: https://github.com/ByteDance-Seed/SeedVR
- FlashVSR: https://github.com/OpenImagingLab/FlashVSR

`models_manifest.json` pins native files to immutable model-repository commits and expected LFS SHA256 values. `local_model_revisions.json` pins the additional local model snapshots. The installer pins ComfyUI and major model-code checkouts and writes per-environment `pip freeze` records after setup. It is not a fully resolved, cross-platform dependency lockfile; a clean GPU-host installation test remains necessary.

This package's original code is MIT licensed. External model/code licenses remain with their authors; weights are not redistributed in the ZIP. H3 uses its community license. See each linked model's actual terms for your production use.
